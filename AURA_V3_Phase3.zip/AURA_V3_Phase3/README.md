# AURA V1 — Phase 3: Agent Engine (builds on Phase 2)

Compilation and tests were NOT executed when this project was generated (no Gradle/Android SDK/network in the generating environment).

## Architecture
UI (ChatScreen / SettingsScreen) -> ViewModels -> ChatRepository / ConfigRepository -> AIProvider

- `domain/`: AIProvider, AIStreamingProvider, AIRequest/AIResponse/AIResult/AIError, ContextManager, SystemPrompts, DemoAIProvider, FallbackAIProvider.
- `data/remote/`: CloudAIProvider (OkHttp), OpenAiCompat (JSON), NetworkMonitor, ConnectionTester, AIProviderFactory.
- `data/config`, `data/secure`: settings + Android-Keystore-encrypted API key.
- `di/AppContainer`: manual wiring (no DI framework).
- Room DB v2 with `MIGRATION_1_2` (adds `provider`, `model` columns; Phase 1 history is kept).

## Cloud provider setup
CloudAIProvider speaks the widely used "chat completions" format: `POST <Base URL>/chat/completions`, header `Authorization: Bearer <key>`, optional SSE streaming. Many services offer this; others do not. Check your provider's docs.
1. Open AURA -> gear icon (Settings).
2. Provider name: any label. Base URL: `https://…/v1` style (https only). Model: exactly as your provider names it.
3. Paste your API key (field is masked; "Show" toggles). Tap Save. The key is encrypted with an Android Keystore AES-GCM key and is never shown again.
4. Tap Test Connection. It saves, then sends one real request.

Never put keys in source, README, Git or screenshots.

## Behaviour
- No cloud config -> Local Demo answers (labelled "Local Demo").
- Each assistant message shows `Provider: … · model`.
- Streaming: real provider streaming only; if disabled/unsupported, normal response mode. Cancel (X) stops the network call.
- Retry: transient errors (offline, timeout, 5xx, 429) are retried up to 3 attempts with backoff. Auth/config/invalid-response errors are not. A Retry button re-asks for the last message without duplicating it.
- Optional "Use Local Demo if the cloud is unreachable": only for availability errors, never auth/config errors; the reply is labelled "Local Demo (fallback)".
- Context: last N messages (Settings, 2–50) and a 16,000 character cap are sent, plus the system prompt. Nothing else.
- Logs contain only event names and error types.

## Build
Same as Phase 1: push to GitHub and run the "Build debug APK" workflow (runs unit tests, builds, uploads the APK), or `gradle testDebugUnitTest assembleDebug` locally (Gradle 8.7, JDK 17, Android SDK 34).

## Tests (JVM)
Provider (MockWebServer): success, empty, malformed, 401, 429/5xx, timeout, network failure, offline, streaming. Repository: saving, failures, retry, bounded retries, streaming, context limit. ViewModel: states, duplicate-send, cancel, clear. Config: save/retrieve, validation, key not exposed. Not covered: Keystore encryption and the Room migration (need an Android device/instrumented tests).

## Troubleshooting
- "Invalid Configuration": Base URL must be https, model must be set; HTTP 400/404 usually means a wrong URL or model name.
- "Authentication Failed": key rejected; re-enter it and Save.
- "No internet connection": check connectivity; Retry appears after failures.
- "Secure connection failed": Base URL host or certificate problem.


---
# Phase 3: Agent Engine

## Flow
User message -> `AuraOrchestrator` -> intent
- CHAT / QUESTION / UNKNOWN -> normal Phase 2 AI chat (no task, no tools)
- TASK / MULTI_STEP_TASK / TOOL_REQUEST / SYSTEM_COMMAND -> `AgentEngine`:
  understand -> plan -> **validate** -> per step: `ToolRouter` (registered? args valid? policy? permission? confirmation?) -> execute -> observe -> retry/continue -> final response. Every state change is saved as a `Task`.

## What Phase 3 can do
Built-in safe tools only: `get_current_time`, `get_app_info`, `get_device_info` (Android version, SDK, manufacturer, model), `echo`, `calculate` (own arithmetic parser, no code execution), `demo_confirmation_action` (HIGH risk, does nothing real; used to try the confirmation dialog).
Try: "What Android version am I using?", "Calculate 25 * 4 + 10", "Run the confirmation demo", "What time is it and what Android version am I using?".

## What it cannot do (by design)
No Android control, accessibility, files, web, messages, purchases, shell/Kotlin/Python execution, memory, voice or self-modification. The AI never runs code: it can only request a registered tool, and the request is validated like any other input.

## Security architecture
- `SecurityPolicy` is the single place for decisions: LOW runs; MEDIUM by policy (default: runs); HIGH and CRITICAL always need confirmation.
- A plan step may *add* `requiresConfirmation`, never remove it. Only the confirmation dialog (a user tap) can approve; nothing in the AI path can call it.
- Plans are validated before running: non-empty, step count <= max, unique ids, tool registered, arguments match the schema (types, required, enum, unexpected args rejected).
- Limits (`AgentConfig`): 10 steps (retries count), 60 s per task, 15 s per tool, 2 retries per step. Loop guard stops >3 identical calls or A,B,A,B,A,B patterns.
- Retries only for transient failures of idempotent tools. Never for invalid args, unknown tools, denied/permission, cancellation.
- Logs contain event names only, never arguments, text or keys.

## Intent / planner behaviour
- Intent: local heuristic first. With a real (non-demo) provider and a task-like message, the AI classifier is asked for JSON; it can turn a task back into chat but can never create a task from a chat message. Invalid output -> UNKNOWN -> chat. Confidence is metadata only.
- Planner: demo provider -> offline rule-based planner (keyword matches only); cloud provider -> AI planner producing JSON, validated before use; if the cloud planner is unreachable the rule-based planner is used.
- Final answer: cloud provider writes it from real tool results; with the demo provider (or on failure) AURA shows a clearly labelled "AURA Agent (local summary)", not an AI answer.

## Tasks screen
Chat -> "Tasks": list (symbols: ✓ done, ⟳ running, ✕ failed/timed out, ○ cancelled) and detail (request, status, plan, steps, result, error, timeline). Tasks left unfinished when the app closes are marked FAILED on next start. Cancel a running task from the progress card.

## Database
Room v3. `MIGRATION_2_3` creates `tasks`; `chat_messages` is untouched (history kept).

## Build and test
GitHub Actions workflow "Build debug APK" runs `gradle testDebugUnitTest assembleDebug`. Locally: Gradle 8.7, JDK 17, Android SDK 34.
Not covered by automated tests: Room migrations and Keystore (need a device), Compose UI.

## Known limitations
- Task-level "retry" is automatic per step only; there is no manual re-run button yet.
- The rule-based planner understands only the built-in tool phrases listed above.
- With a cloud provider, classification/planning/answering add extra model calls for task messages.
