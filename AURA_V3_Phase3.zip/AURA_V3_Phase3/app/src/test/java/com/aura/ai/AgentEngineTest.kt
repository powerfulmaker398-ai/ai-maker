package com.aura.ai

import com.aura.ai.agent.*
import com.aura.ai.data.ChatRepository
import com.aura.ai.domain.AIResponse
import com.aura.ai.domain.AIResult
import com.aura.ai.domain.Role
import com.aura.ai.intent.IntentResult
import com.aura.ai.intent.IntentType
import com.aura.ai.intent.HeuristicIntentClassifier
import com.aura.ai.permissions.AllowAllPermissionManager
import com.aura.ai.permissions.SecurityPolicy
import com.aura.ai.planner.Plan
import com.aura.ai.planner.PlanResult
import com.aura.ai.planner.PlanStep
import com.aura.ai.planner.Planner
import com.aura.ai.task.StepStatus
import com.aura.ai.task.TaskRepository
import com.aura.ai.task.TaskState
import com.aura.ai.tools.*
import com.aura.ai.tools.builtin.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

private class FixedPlanner(private val result: PlanResult) : Planner {
    override suspend fun createPlan(userInput: String, goal: String) = result
}

private class FixedResponder(private val text: String = "final answer") : AgentResponder {
    var calls = 0
    override suspend fun respond(userRequest: String, observations: List<Observation>): AIResult {
        calls++
        return AIResult.Success(AIResponse(text, "Resp"))
    }
}

private fun planOf(vararg steps: Pair<String, Map<String, Any?>>, confirm: Boolean = false) =
    PlanResult.Valid(Plan("p", "goal", steps.mapIndexed { i, s -> PlanStep("s${i + 1}", "step ${i + 1}", s.first, s.second, confirm) }))

private class Env(
    tools: List<AuraTool>,
    plan: PlanResult,
    config: AgentConfig = AgentConfig(),
    approve: Boolean = true,
    val responder: FixedResponder = FixedResponder()
) {
    val registry = InMemoryToolRegistry().apply { tools.forEach { register(it) } }
    val policy = SecurityPolicy()
    val confirm = FakeConfirm(approve)
    val repo = TaskRepository(FakeTaskDao())
    val engine = AgentEngine(
        FixedPlanner(plan), ToolRouter(registry, policy, AllowAllPermissionManager(), confirm),
        registry, policy, repo, responder, config
    )
    val intent = IntentResult(IntentType.TASK, "goal")
    suspend fun run() = engine.execute("do it", intent)
    suspend fun task(id: String) = repo.get(id)!!
}

class AgentEngineTest {
    private val none = emptyMap<String, Any?>()

    @Test fun successfulTask() = runTest {
        val dev = GetDeviceInfoTool { DeviceInfo("14", 34, "Google", "Pixel") }
        val e = Env(listOf(dev), planOf(ToolNames.DEVICE_INFO to none))
        val r = e.run()
        assertEquals(TaskState.COMPLETED, r.state)
        assertEquals("final answer", r.finalText)
        val t = e.task(r.taskId)
        assertEquals(TaskState.COMPLETED, t.state)
        assertEquals(StepStatus.DONE, t.steps.single().status)
        assertTrue(t.steps.single().summary!!.contains("Android 14"))
        assertTrue(t.timeline.any { it.label == "Plan validated" })
        assertEquals("final answer", t.result)
    }

    @Test fun calculatorTaskProduces110() = runTest {
        val e = Env(listOf(CalculateTool()), planOf(ToolNames.CALCULATE to mapOf("expression" to "25 * 4 + 10")))
        val r = e.run()
        assertEquals(TaskState.COMPLETED, r.state)
        assertTrue(e.task(r.taskId).steps.single().summary!!.endsWith("= 110"))
    }

    @Test fun failedToolFailsTaskWithoutRetry() = runTest {
        val bad = FakeTool("bad_tool") { ToolResult.Failure("boom") }
        val e = Env(listOf(bad), planOf("bad_tool" to none))
        val r = e.run()
        assertEquals(TaskState.FAILED, r.state)
        assertTrue(r.error!!.contains("boom"))
        assertEquals(1, bad.calls)
        assertEquals(0, e.responder.calls)
    }

    @Test fun transientFailureIsRetried() = runTest {
        val flaky = FakeTool("flaky") { n -> if (n < 3) ToolResult.Failure("temporary", retryable = true) else ToolResult.Success("ok") }
        val e = Env(listOf(flaky), planOf("flaky" to none))
        val r = e.run()
        assertEquals(TaskState.COMPLETED, r.state)
        assertEquals(3, flaky.calls)
        assertTrue(e.task(r.taskId).timeline.any { it.label.startsWith("Retrying") })
    }

    @Test fun nonIdempotentToolIsNeverAutoRetried() = runTest {
        val t = FakeTool("side_effect", isIdempotent = false) { ToolResult.Failure("temporary", retryable = true) }
        val r = Env(listOf(t), planOf("side_effect" to none)).run()
        assertEquals(TaskState.FAILED, r.state)
        assertEquals(1, t.calls)
    }

    @Test fun invalidArgumentsAreNotRetried() = runTest {
        val t = FakeTool("typed", arguments = listOf(ToolArgument("n", ArgType.INTEGER)))
        val r = Env(listOf(t), planOf("typed" to mapOf("n" to "x"))).run()
        assertEquals(TaskState.FAILED, r.state)  // rejected by the plan validator before any execution
        assertEquals(0, t.calls)
    }

    @Test fun unknownToolPlanRejected() = runTest {
        val echo = FakeTool("echo_like")
        val r = Env(listOf(echo), planOf("delete_everything" to none)).run()
        assertEquals(TaskState.FAILED, r.state)
        assertTrue(r.error!!.contains("Plan rejected"))
        assertEquals(0, echo.calls)
    }

    @Test fun plannerReturningNoStepsFailsSafely() = runTest {
        val r = Env(emptyList(), PlanResult.Invalid("The planner returned no steps.")).run()
        assertEquals(TaskState.FAILED, r.state)
    }

    @Test fun planWithTooManyStepsIsRejected() = runTest {
        val t = FakeTool("t_a")
        val steps = (1..5).map { "t_a" to mapOf<String, Any?>() }.toTypedArray()
        val e = Env(listOf(t), planOf(*steps), AgentConfig(maxSteps = 3))
        val r = e.run()
        assertEquals(TaskState.FAILED, r.state)
        assertTrue(r.error!!.contains("maximum number of steps"))
        assertEquals(0, t.calls)
    }

    @Test fun maximumStepsStopsRetryLoop() = runTest {
        val t = FakeTool("flaky") { ToolResult.Failure("temporary", retryable = true) }
        val r = Env(listOf(t), planOf("flaky" to none), AgentConfig(maxSteps = 3, maxRetriesPerStep = 10)).run()
        assertEquals(TaskState.FAILED, r.state)
        assertTrue(r.error!!.contains("maximum number of steps"))
        assertEquals(3, t.calls)
    }

    @Test fun repeatedIdenticalCallsStopped() = runTest {
        val t = FakeTool("t_a")
        val steps = (1..4).map { "t_a" to mapOf<String, Any?>() }.toTypedArray()
        val r = Env(listOf(t), planOf(*steps)).run()
        assertEquals(TaskState.FAILED, r.state)
        assertTrue(r.error!!.contains("repeated"))
        assertEquals(3, t.calls)
    }

    @Test fun alternatingLoopStopped() = runTest {
        val a = FakeTool("tool_a"); val b = FakeTool("tool_b")
        val steps = listOf("tool_a", "tool_b", "tool_a", "tool_b", "tool_a", "tool_b").map { it to mapOf<String, Any?>() }.toTypedArray()
        val r = Env(listOf(a, b), planOf(*steps)).run()
        assertEquals(TaskState.FAILED, r.state)
        assertEquals(5, a.calls + b.calls)
    }

    @Test fun cancellationStopsAgentAndLaterTools() = runTest {
        val slow = FakeTool("slow") { awaitCancellation() }
        val later = FakeTool("later")
        val e = Env(listOf(slow, later), planOf("slow" to none, "later" to none))
        val job: Job = launch { e.run() }
        runCurrent()
        job.cancel()
        job.join()
        val t = e.repo.tasks.first().single()
        assertEquals(TaskState.CANCELLED, t.state)
        assertEquals(0, later.calls)
    }

    @Test fun totalTimeoutMarksTaskTimedOut() = runTest {
        val slow = FakeTool("slow") { delay(10_000); ToolResult.Success("late") }
        val later = FakeTool("later")
        val e = Env(listOf(slow, later), planOf("slow" to none, "later" to none), AgentConfig(maxDurationMs = 1_000, toolTimeoutMs = 60_000))
        val r = e.run()
        assertEquals(TaskState.TIMED_OUT, r.state)
        assertEquals("Task timed out.", e.task(r.taskId).error)
        assertEquals(0, later.calls)
    }

    @Test fun toolLevelTimeoutIsReportedAndRetriedOnlyIfIdempotent() = runTest {
        val slow = FakeTool("slow") { delay(10_000); ToolResult.Success("late") }
        val e = Env(listOf(slow), planOf("slow" to none), AgentConfig(toolTimeoutMs = 100, maxRetriesPerStep = 1))
        val r = e.run()
        assertEquals(TaskState.FAILED, r.state)
        assertEquals(2, slow.calls)
    }

    @Test fun deniedConfirmationNeverExecutesAndCancelsTask() = runTest {
        val danger = FakeTool("danger_tool", risk = ToolRisk.HIGH)
        val e = Env(listOf(danger), planOf("danger_tool" to none), approve = false)
        val r = e.run()
        assertEquals(TaskState.CANCELLED, r.state)
        assertEquals(0, danger.calls)
        assertEquals(1, e.confirm.requests.size)
        assertTrue(e.task(r.taskId).timeline.any { it.label == "Permission denied" })
    }

    @Test fun approvedConfirmationExecutes() = runTest {
        val danger = FakeTool("danger_tool", risk = ToolRisk.CRITICAL)
        val e = Env(listOf(danger), planOf("danger_tool" to none), approve = true)
        assertEquals(TaskState.COMPLETED, e.run().state)
        assertEquals(1, danger.calls)
    }
}

class TaskStateMachineTest {
    @Test fun validAndInvalidTransitions() {
        assertTrue(TaskState.QUEUED.canTransitionTo(TaskState.UNDERSTANDING))
        assertTrue(TaskState.RUNNING.canTransitionTo(TaskState.RETRYING))
        assertTrue(TaskState.WAITING_PERMISSION.canTransitionTo(TaskState.CANCELLED))
        assertFalse(TaskState.QUEUED.canTransitionTo(TaskState.RUNNING))
        assertFalse(TaskState.PLANNING.canTransitionTo(TaskState.COMPLETED))
        TaskState.values().filter { it.terminal }.forEach { t ->
            TaskState.values().forEach { n -> assertFalse("$t -> $n", t.canTransitionTo(n)) }
        }
    }
}

class OrchestratorTest {
    private class RecordingAgent : AgentRunner {
        var calls = 0
        override suspend fun execute(userRequest: String, intent: IntentResult, onTaskCreated: (String) -> Unit): AgentResult {
            calls++; onTaskCreated("task-1")
            return AgentResult("task-1", TaskState.COMPLETED, "You use Android 14", "AURA Agent (local summary)", null)
        }
    }

    @Test fun normalChatUsesNoAgentAndNoTool() = runTest {
        val dao = FakeDao(); val provider = ScriptedProvider(ok("Kotlin is a language"))
        val agent = RecordingAgent()
        val repo = ChatRepository(dao, { provider }, { 20 }, retryDelayMs = 0)
        val o = AuraOrchestrator(HeuristicIntentClassifier(), agent, repo)
        assertTrue(o.handle("What is Kotlin?", {}, {}) is AIResult.Success)
        assertEquals(0, agent.calls)
        assertEquals(1, provider.calls)
        assertEquals(listOf(Role.USER, Role.ASSISTANT), repo.messages.first().map { it.role })
    }

    @Test fun taskGoesToAgentNotChatProvider() = runTest {
        val dao = FakeDao(); val provider = ScriptedProvider(ok("should not be used"))
        val agent = RecordingAgent()
        val repo = ChatRepository(dao, { provider }, { 20 }, retryDelayMs = 0)
        val o = AuraOrchestrator(HeuristicIntentClassifier(), agent, repo)
        var created: String? = null
        assertTrue(o.handle("What Android version am I using?", {}, { created = it }) is AIResult.Success)
        assertEquals(1, agent.calls)
        assertEquals("task-1", created)
        assertEquals(0, provider.calls)
        val msgs = repo.messages.first()
        assertEquals("You use Android 14", msgs.last().content)
        assertEquals("AURA Agent (local summary)", msgs.last().provider)
    }

    @Test fun failedTaskIsReportedNotHidden() = runTest {
        val failing = object : AgentRunner {
            override suspend fun execute(userRequest: String, intent: IntentResult, onTaskCreated: (String) -> Unit) =
                AgentResult("t", TaskState.FAILED, null, null, "Step 1 failed: boom")
        }
        val repo = ChatRepository(FakeDao(), { ScriptedProvider(ok()) }, { 20 })
        val r = AuraOrchestrator(HeuristicIntentClassifier(), failing, repo).handle("Calculate 1 + 1", {}, {})
        assertTrue(r is AIResult.Failure)
        assertTrue(repo.messages.first().last().content.contains("boom"))
    }
}
