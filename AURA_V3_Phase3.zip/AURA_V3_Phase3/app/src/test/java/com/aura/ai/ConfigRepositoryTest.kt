package com.aura.ai

import com.aura.ai.data.config.ConfigRepository
import com.aura.ai.data.remote.ConnectionStatus
import com.aura.ai.data.remote.ConnectionTester
import com.aura.ai.domain.AIErrorType
import com.aura.ai.domain.AIProviderConfig
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfigRepositoryTest {
    private val store = MemoryStore()
    private val secrets = MemorySecrets()
    private val repo = ConfigRepository(store, secrets)

    @Test fun saveAndRetrieve() {
        assertNull(repo.saveProvider("Prov", "https://api.example.com/v1", "m1", "sk-secret-123"))
        val cfg = repo.loadProviderConfig()
        assertEquals("m1", cfg.model)
        assertEquals("sk-secret-123", cfg.apiKey)
        assertTrue(repo.snapshot.value.cloudConfigured)
    }

    @Test fun keyIsNotExposedInSnapshotToStringOrPlainStore() {
        repo.saveProvider("Prov", "https://api.example.com/v1", "m1", "sk-secret-123")
        assertFalse(repo.snapshot.value.toString().contains("sk-secret-123"))
        assertFalse(repo.loadProviderConfig().toString().contains("sk-secret-123"))
        assertFalse(store.map.values.any { it.contains("sk-secret-123") })
    }

    @Test fun invalidUrlIsRejected() {
        assertNotNull(repo.saveProvider("Prov", "http://insecure.example.com", "m", "k"))
        assertNotNull(repo.saveProvider("Prov", "not a url", "m", "k"))
        assertNotNull(AIProviderConfig("P", "https://x.com", "", "k").validationError())
    }

    @Test fun blankKeyKeepsExistingKey() {
        repo.saveProvider("Prov", "https://a.example.com/v1", "m", "sk-1")
        repo.saveProvider("Prov", "https://a.example.com/v1", "m2", "")
        assertEquals("sk-1", repo.loadProviderConfig().apiKey)
        assertEquals("m2", repo.snapshot.value.model)
    }

    @Test fun notConfiguredWithoutKeyAndClearRemovesKey() {
        repo.saveProvider("Prov", "https://a.example.com/v1", "m", null)
        assertFalse(repo.snapshot.value.cloudConfigured)
        repo.saveProvider("Prov", "https://a.example.com/v1", "m", "k")
        repo.clearApiKey()
        assertFalse(repo.snapshot.value.hasApiKey)
    }

    @Test fun chatSettingsAreClamped() {
        repo.saveChatSettings(1000, streaming = false, demoFallback = true)
        assertEquals(ConfigRepository.MAX_MAX, repo.snapshot.value.maxContextMessages)
        assertFalse(repo.snapshot.value.streamingEnabled)
        assertTrue(repo.snapshot.value.demoFallbackEnabled)
    }

    @Test fun connectionTesterReportsRealOutcomes() = runBlocking {
        val unconfigured = ConnectionTester(repo) { ScriptedProvider(ok()) }
        val s0 = unconfigured.test()
        assertTrue(s0 is ConnectionStatus.Failed && s0.title == "Invalid Configuration")

        repo.saveProvider("Prov", "https://a.example.com/v1", "m", "k")
        val good = ConnectionTester(repo) { ScriptedProvider(ok()) }.test()
        assertTrue(good is ConnectionStatus.Connected)
        val auth = ConnectionTester(repo) { ScriptedProvider(fail(AIErrorType.INVALID_API_KEY)) }.test()
        assertTrue(auth is ConnectionStatus.Failed && auth.title == "Authentication Failed")
        val net = ConnectionTester(repo) { ScriptedProvider(fail(AIErrorType.NETWORK_UNAVAILABLE)) }.test()
        assertTrue(net is ConnectionStatus.Failed && net.title == "Network Unavailable")
    }
}
