package com.aura.ai

import com.aura.ai.domain.DemoAIProvider
import com.aura.ai.intent.*
import com.aura.ai.permissions.SecurityPolicy
import com.aura.ai.planner.*
import com.aura.ai.tools.ArgType
import com.aura.ai.tools.InMemoryToolRegistry
import com.aura.ai.tools.ToolArgument
import com.aura.ai.tools.ToolRisk
import com.aura.ai.tools.builtin.ToolNames
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class IntentTest {
    private val h = HeuristicIntentClassifier()
    private fun type(s: String) = runBlocking { h.classify(s).type }

    @Test fun chatAndQuestionsStayConversation() {
        assertEquals(IntentType.CHAT, type("Hello"))
        assertEquals(IntentType.QUESTION, type("What is Kotlin?"))
        assertEquals(IntentType.QUESTION, type("Explain photosynthesis."))
        assertFalse(type("What is Kotlin?").usesAgent)
    }
    @Test fun taskIntents() {
        assertEquals(IntentType.TASK, type("What Android version am I using?"))
        assertEquals(IntentType.TASK, type("Calculate 25 * 4 + 10."))
        assertEquals(IntentType.MULTI_STEP_TASK, type("Check my device information and summarize it"))
        assertEquals(IntentType.UNKNOWN, type("   "))
    }

    @Test fun aiClassifierParsesValidJson() {
        val r = AIIntentClassifier.parse("{\"intent\":\"TASK\",\"confidence\":0.91,\"goal\":\"Get device information\"}", "x")!!
        assertEquals(IntentType.TASK, r.type)
        assertEquals("Get device information", r.goal)
        assertEquals(0.91, r.confidence!!, 0.0001)
        assertEquals(IntentType.CHAT, AIIntentClassifier.parse("```json\n{\"intent\":\"chat\"}\n```", "hi")!!.type)
    }
    @Test fun aiClassifierMalformedBecomesUnknown() = runBlocking {
        listOf("not json", "{\"intent\":\"DELETE_ALL\"}", "{\"intent\":\"UNKNOWN\"}", "{}").forEach {
            assertNull(AIIntentClassifier.parse(it, "x"))
        }
        val c = AIIntentClassifier { ScriptedProvider(ok("blah blah")) }
        assertEquals(IntentType.UNKNOWN, c.classify("anything").type)
        val failing = AIIntentClassifier { ScriptedProvider(fail(com.aura.ai.domain.AIErrorType.TIMEOUT)) }
        assertEquals(IntentType.UNKNOWN, failing.classify("anything").type)
    }
    @Test fun confidenceIsClampedMetadata() {
        assertEquals(1.0, AIIntentClassifier.parse("{\"intent\":\"TASK\",\"confidence\":7}", "x")!!.confidence!!, 0.0)
    }
    @Test fun hybridDoesNotConsultAiForChatAndCannotCreateTasks() = runBlocking {
        val ai = ScriptedProvider(ok("{\"intent\":\"TASK\",\"goal\":\"x\"}"))
        val hybrid = HybridIntentClassifier(h, AIIntentClassifier { ai }) { ai }
        assertEquals(IntentType.QUESTION, hybrid.classify("What is Kotlin?").type)
        assertEquals(0, ai.calls)
    }
    @Test fun hybridUsesHeuristicWithDemoProviderAndAiMayDowngrade() = runBlocking {
        val demo = HybridIntentClassifier(h, AIIntentClassifier { ScriptedProvider(ok()) }) { DemoAIProvider() }
        assertEquals(IntentType.TASK, demo.classify("What Android version am I using?").type)
        val ai = ScriptedProvider(ok("{\"intent\":\"QUESTION\",\"goal\":\"g\"}"))
        val hybrid = HybridIntentClassifier(h, AIIntentClassifier { ai }) { ai }
        assertEquals(IntentType.QUESTION, hybrid.classify("What Android version am I using?").type)
    }
}

class PlannerTest {
    private val registry = InMemoryToolRegistry().apply {
        register(com.aura.ai.tools.builtin.EchoTool())
        register(com.aura.ai.tools.builtin.CalculateTool())
        register(com.aura.ai.tools.builtin.ConfirmationDemoTool())
        register(FakeTool("no_args"))
    }
    private val policy = SecurityPolicy()
    private fun validate(p: Plan, max: Int = 10) = PlanValidator.validate(p, registry, policy, max)
    private fun step(id: String, tool: String?, args: Map<String, Any?> = emptyMap(), confirm: Boolean = false) =
        PlanStep(id, "d", tool, args, confirm)

    @Test fun parsesValidPlan() {
        val json = "{\"goal\":\"g\",\"steps\":[{\"description\":\"calc\",\"tool\":\"calculate\",\"arguments\":{\"expression\":\"1+1\"}}]}"
        val r = PlanParser.parse(json, "fallback") as PlanResult.Valid
        assertEquals("calculate", r.plan.steps.single().toolName)
        assertTrue(validate(r.plan) is PlanValidation.Valid)
    }
    @Test fun emptyAndMalformedPlansRejected() {
        assertTrue(PlanParser.parse("{\"goal\":\"g\",\"steps\":[]}", "g") is PlanResult.Invalid)
        assertTrue(PlanParser.parse("hello", "g") is PlanResult.Invalid)
        assertTrue(PlanParser.parse("{\"steps\":[5]}", "g") is PlanResult.Invalid)
        assertTrue(PlanParser.parse("{\"steps\":[{\"tool\":\"echo\",\"arguments\":7}]}", "g") is PlanResult.Invalid)
        assertTrue(validate(Plan("p", "g", emptyList())) is PlanValidation.Invalid)
    }
    @Test fun unknownToolRejected() {
        val v = validate(Plan("p", "g", listOf(step("s1", "delete_everything"))))
        assertTrue(v is PlanValidation.Invalid && v.reason.contains("Unknown tool"))
    }
    @Test fun excessiveStepsRejected() {
        val steps = (1..5).map { step("s$it", "no_args") }
        val v = validate(Plan("p", "g", steps), max = 3)
        assertTrue(v is PlanValidation.Invalid && v.reason.contains("maximum number of steps"))
    }
    @Test fun malformedArgumentsRejected() {
        assertTrue(validate(Plan("p", "g", listOf(step("s1", "calculate", mapOf("expression" to 5))))) is PlanValidation.Invalid)
        assertTrue(validate(Plan("p", "g", listOf(step("s1", "calculate")))) is PlanValidation.Invalid)
        assertTrue(validate(Plan("p", "g", listOf(step("s1", "no_args", mapOf("steps" to listOf(1)))))) is PlanValidation.Invalid)
    }
    @Test fun riskEvaluationForcesConfirmationFlag() {
        val v = validate(Plan("p", "g", listOf(step("s1", "demo_confirmation_action", confirm = false)))) as PlanValidation.Valid
        assertTrue(v.plan.steps.single().requiresConfirmation)
    }
    @Test fun ruleBasedPlanner() = runBlocking {
        val p = RuleBasedPlanner()
        val calc = p.createPlan("Calculate 25 * 4 + 10.", "g") as PlanResult.Valid
        assertEquals(ToolNames.CALCULATE, calc.plan.steps.single().toolName)
        assertEquals("25 * 4 + 10", calc.plan.steps.single().arguments["expression"])
        val dev = p.createPlan("What Android version am I using?", "g") as PlanResult.Valid
        assertEquals(ToolNames.DEVICE_INFO, dev.plan.steps.single().toolName)
        assertTrue(p.createPlan("Tell me a joke", "g") is PlanResult.Invalid)
    }
}
