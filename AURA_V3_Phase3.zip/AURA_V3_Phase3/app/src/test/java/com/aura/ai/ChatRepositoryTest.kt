package com.aura.ai

import com.aura.ai.data.ChatRepository
import com.aura.ai.domain.AIErrorType
import com.aura.ai.domain.AIResponse
import com.aura.ai.domain.AIResult
import com.aura.ai.domain.DemoAIProvider
import com.aura.ai.domain.Role
import com.aura.ai.domain.StreamEvent
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatRepositoryTest {
    private fun repo(dao: FakeDao, p: com.aura.ai.domain.AIProvider, attempts: Int = 3) =
        ChatRepository(dao, { p }, { 20 }, maxAttempts = attempts, retryDelayMs = 0)

    @Test fun savesUserAndAssistantWithProvider() = runTest {
        val r = repo(FakeDao(), ScriptedProvider(ok("hello", "Cloud X")))
        assertTrue(r.send("hi") is AIResult.Success)
        val m = r.messages.first()
        assertEquals(listOf(Role.USER, Role.ASSISTANT), m.map { it.role })
        assertEquals("Cloud X", m[1].provider)
        assertEquals("test-model", m[1].model)
    }

    @Test fun demoProviderIsLabelledAsDemo() = runTest {
        val r = repo(FakeDao(), DemoAIProvider())
        r.send("Hello")
        val reply = r.messages.first()[1]
        assertEquals("Local Demo", reply.provider)
        assertTrue(reply.content.contains("no real AI model"))
    }

    @Test fun failedRequestCreatesNoAssistantMessage() = runTest {
        val r = repo(FakeDao(), ScriptedProvider(fail(AIErrorType.INVALID_API_KEY)))
        val res = r.send("hi")
        assertTrue(res is AIResult.Failure)
        assertEquals(listOf(Role.USER), r.messages.first().map { it.role })
    }

    @Test fun retryDoesNotDuplicateUserMessage() = runTest {
        val r = repo(FakeDao(), ScriptedProvider(fail(AIErrorType.NETWORK_UNAVAILABLE), ok("later")), attempts = 1)
        assertTrue(r.send("hi") is AIResult.Failure)
        assertTrue(r.retry() is AIResult.Success)
        assertEquals(listOf(Role.USER, Role.ASSISTANT), r.messages.first().map { it.role })
    }

    @Test fun transientFailureIsRetriedAndBounded() = runTest {
        val flaky = ScriptedProvider(fail(AIErrorType.TIMEOUT), fail(AIErrorType.TIMEOUT), ok())
        assertTrue(repo(FakeDao(), flaky).send("hi") is AIResult.Success)
        assertEquals(3, flaky.calls)

        val dead = ScriptedProvider(fail(AIErrorType.SERVER_ERROR))
        assertTrue(repo(FakeDao(), dead).send("hi") is AIResult.Failure)
        assertEquals(3, dead.calls)
    }

    @Test fun nonRetryableFailureIsNotRetried() = runTest {
        val p = ScriptedProvider(fail(AIErrorType.INVALID_API_KEY))
        repo(FakeDao(), p).send("hi")
        assertEquals(1, p.calls)
    }

    @Test fun streamingDeliversPartialsAndSavesFinalText() = runTest {
        val p = StreamingScripted(listOf(
            StreamEvent.Delta("Hel"), StreamEvent.Delta("lo"),
            StreamEvent.Complete(AIResponse("Hello", "S", "m"))
        ))
        val partials = mutableListOf<String>()
        val r = repo(FakeDao(), p)
        assertTrue(r.send("hi") { partials.add(it) } is AIResult.Success)
        assertEquals(listOf("Hel", "Hello"), partials)
        assertEquals("Hello", r.messages.first()[1].content)
    }

    @Test fun emptyInputAndEmptyResponseFailSafely() = runTest {
        val r = repo(FakeDao(), ScriptedProvider(ok("   ")))
        assertTrue(r.send("  ") is AIResult.Failure)
        assertTrue(r.messages.first().isEmpty())
        assertTrue(r.send("hi") is AIResult.Failure)
        assertEquals(1, r.messages.first().size)
    }

    @Test fun contextIsLimited() = runTest {
        val p = ScriptedProvider(ok())
        val r = ChatRepository(FakeDao(), { p }, { 2 }, retryDelayMs = 0)
        repeat(4) { r.send("m$it") }
        assertTrue(p.lastRequest!!.conversation.size <= 2)
        assertEquals("m3", p.lastRequest!!.userInput)
    }

    @Test fun clearEmptiesHistory() = runTest {
        val r = repo(FakeDao(), ScriptedProvider(ok()))
        r.send("hi"); r.clear()
        assertTrue(r.messages.first().isEmpty())
    }
}
