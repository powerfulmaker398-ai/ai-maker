package com.aura.ai

import com.aura.ai.agent.AuraOrchestrator
import com.aura.ai.data.ChatRepository
import com.aura.ai.intent.HeuristicIntentClassifier
import com.aura.ai.permissions.UiConfirmationManager
import com.aura.ai.task.TaskRepository
import com.aura.ai.data.config.ConfigRepository
import com.aura.ai.domain.AIErrorType
import com.aura.ai.domain.AIProvider
import com.aura.ai.ui.ChatPhase
import com.aura.ai.ui.ChatViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModelTest {
    private val dispatcher = UnconfinedTestDispatcher()

    @Before fun setUp() { Dispatchers.setMain(dispatcher) }
    @After fun tearDown() { Dispatchers.resetMain() }

    private fun vm(p: AIProvider): ChatViewModel {
        val repo = ChatRepository(FakeDao(), { p }, { 20 }, maxAttempts = 1, retryDelayMs = 0)
        return ChatViewModel(
            repo, AuraOrchestrator(HeuristicIntentClassifier(), NoAgent, repo),
            ConfigRepository(MemoryStore(), MemorySecrets()), TaskRepository(FakeTaskDao()), UiConfirmationManager()
        )
    }

    @Test fun successFlow() = runTest(dispatcher) {
        val vm = vm(ScriptedProvider(ok()))
        backgroundScope.launch { vm.state.collect { } }
        vm.send("hi")
        assertEquals(ChatPhase.SUCCESS, vm.state.value.phase)
        assertEquals(2, vm.state.value.messages.size)
        assertTrue(!vm.state.value.canRetry)
    }

    @Test fun errorThenRetry() = runTest(dispatcher) {
        val vm = vm(ScriptedProvider(fail(AIErrorType.TIMEOUT), ok()))
        backgroundScope.launch { vm.state.collect { } }
        vm.send("hi")
        assertEquals(ChatPhase.ERROR, vm.state.value.phase)
        assertEquals(AIErrorType.TIMEOUT, vm.state.value.error?.type)
        assertTrue(vm.state.value.canRetry)
        assertEquals(1, vm.state.value.messages.size)
        vm.retry()
        assertEquals(ChatPhase.SUCCESS, vm.state.value.phase)
        assertEquals(2, vm.state.value.messages.size)
    }

    @Test fun duplicateSendIsIgnoredWhileBusy() = runTest(dispatcher) {
        val p = GatedProvider()
        val vm = vm(p)
        backgroundScope.launch { vm.state.collect { } }
        vm.send("a")
        assertEquals(ChatPhase.SENDING, vm.state.value.phase)
        vm.send("b")
        assertEquals(1, p.calls)
        p.gate.complete(Unit)
        assertEquals(ChatPhase.SUCCESS, vm.state.value.phase)
        assertEquals(2, vm.state.value.messages.size)
    }

    @Test fun cancelKeepsUserMessageAndAllowsRetry() = runTest(dispatcher) {
        val p = GatedProvider()
        val vm = vm(p)
        backgroundScope.launch { vm.state.collect { } }
        vm.send("a")
        vm.cancel()
        assertEquals(ChatPhase.IDLE, vm.state.value.phase)
        assertEquals(1, vm.state.value.messages.size)
        assertTrue(vm.state.value.canRetry)
    }

    @Test fun clearConversation() = runTest(dispatcher) {
        val vm = vm(ScriptedProvider(ok()))
        backgroundScope.launch { vm.state.collect { } }
        vm.send("hi")
        vm.clear()
        assertTrue(vm.state.value.messages.isEmpty())
        assertNotNull(vm.state.value.providerLabel)
    }
}
