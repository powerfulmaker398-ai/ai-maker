package com.aura.ai

import com.aura.ai.data.remote.CloudAIProvider
import com.aura.ai.data.remote.NetworkMonitor
import com.aura.ai.domain.AIErrorType
import com.aura.ai.domain.AIProviderConfig
import com.aura.ai.domain.AIRequest
import com.aura.ai.domain.AIResult
import com.aura.ai.domain.StreamEvent
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.SocketPolicy
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.util.concurrent.TimeUnit

class CloudAIProviderTest {
    private lateinit var server: MockWebServer
    private val req = AIRequest("sys", emptyList(), "hi")

    @Before fun setUp() { server = MockWebServer().apply { start() } }
    @After fun tearDown() { try { server.shutdown() } catch (e: Exception) { } }

    private fun provider(online: Boolean = true, key: String? = "test-key", readMs: Long = 3000, baseUrl: String = server.url("/v1").toString()) =
        CloudAIProvider(
            AIProviderConfig("Test", baseUrl, "m", key),
            OkHttpClient.Builder().readTimeout(readMs, TimeUnit.MILLISECONDS).connectTimeout(2, TimeUnit.SECONDS).build(),
            object : NetworkMonitor { override fun isOnline() = online }
        )

    private fun errorType(r: AIResult) = (r as AIResult.Failure).error.type

    @Test fun success() = runBlocking {
        server.enqueue(MockResponse().setBody("""{"choices":[{"message":{"role":"assistant","content":"Hello"}}]}"""))
        val r = provider().generate(req)
        assertEquals("Hello", (r as AIResult.Success).response.text)
        assertTrue(r.response.provider.startsWith("Cloud AI"))
        val recorded = server.takeRequest()
        assertEquals("/v1/chat/completions", recorded.path)
        assertEquals("Bearer test-key", recorded.getHeader("Authorization"))
    }

    @Test fun emptyAndMalformedResponses() = runBlocking {
        server.enqueue(MockResponse().setBody("""{"choices":[{"message":{"content":""}}]}"""))
        assertEquals(AIErrorType.EMPTY_RESPONSE, errorType(provider().generate(req)))
        server.enqueue(MockResponse().setBody("this is not json"))
        assertEquals(AIErrorType.INVALID_RESPONSE, errorType(provider().generate(req)))
        server.enqueue(MockResponse().setBody("""{"choices":[]}"""))
        assertEquals(AIErrorType.INVALID_RESPONSE, errorType(provider().generate(req)))
    }

    @Test fun authenticationFailureDoesNotLeakBodyOrKey() = runBlocking {
        server.enqueue(MockResponse().setResponseCode(401).setBody("server-detail-should-not-show test-key"))
        val e = (provider().generate(req) as AIResult.Failure).error
        assertEquals(AIErrorType.INVALID_API_KEY, e.type)
        assertFalse(e.retryable)
        assertFalse(e.userMessage.contains("server-detail"))
        assertFalse(e.userMessage.contains("test-key"))
    }

    @Test fun rateLimitAndServerErrorAreRetryable() = runBlocking {
        server.enqueue(MockResponse().setResponseCode(429))
        assertTrue((provider().generate(req) as AIResult.Failure).error.retryable)
        server.enqueue(MockResponse().setResponseCode(503))
        val e = (provider().generate(req) as AIResult.Failure).error
        assertEquals(AIErrorType.SERVER_ERROR, e.type)
        assertTrue(e.retryable)
    }

    @Test fun timeout() = runBlocking {
        server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE))
        assertEquals(AIErrorType.TIMEOUT, errorType(provider(readMs = 300).generate(req)))
    }

    @Test fun networkFailure() = runBlocking {
        val url = server.url("/v1").toString()
        server.shutdown()
        assertEquals(AIErrorType.NETWORK_UNAVAILABLE, errorType(provider(baseUrl = url).generate(req)))
    }

    @Test fun offlineDoesNotTouchNetwork() = runBlocking {
        assertEquals(AIErrorType.NETWORK_UNAVAILABLE, errorType(provider(online = false).generate(req)))
        assertEquals(0, server.requestCount)
    }

    @Test fun missingKeyIsInvalidConfiguration() = runBlocking {
        assertEquals(AIErrorType.INVALID_CONFIGURATION, errorType(provider(key = null).generate(req)))
    }

    @Test fun streamingEmitsDeltasThenComplete() = runBlocking {
        val body = "data: {\"choices\":[{\"delta\":{\"role\":\"assistant\"}}]}\n\n" +
            "data: {\"choices\":[{\"delta\":{\"content\":\"Hel\"}}]}\n\n" +
            "data: {\"choices\":[{\"delta\":{\"content\":\"lo\"}}]}\n\n" +
            "data: [DONE]\n\n"
        server.enqueue(MockResponse().setHeader("Content-Type", "text/event-stream").setBody(body))
        val events = provider().stream(req).toList()
        assertEquals(listOf("Hel", "lo"), events.filterIsInstance<StreamEvent.Delta>().map { it.text })
        assertEquals("Hello", (events.last() as StreamEvent.Complete).response.text)
    }

    @Test fun streamingAuthFailure() = runBlocking {
        server.enqueue(MockResponse().setResponseCode(401))
        val events = provider().stream(req).toList()
        assertEquals(AIErrorType.INVALID_API_KEY, (events.single() as StreamEvent.Failed).error.type)
    }
}
