package com.aura.ai

import com.aura.ai.planner.Plan
import com.aura.ai.planner.PlanStep
import com.aura.ai.task.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test

class TaskPersistenceTest {
    private fun sample(id: String = "t1", state: TaskState = TaskState.COMPLETED) = Task(
        id, "calc", "goal", state, 1000, 2000,
        plan = Plan("p", "goal", listOf(PlanStep("s1", "Calculate", "calculate", mapOf("expression" to "1+1"), false))),
        steps = listOf(StepRecord("s1", "Calculate", "calculate", StepStatus.DONE, "1+1 = 2")),
        currentStep = 0,
        timeline = listOf(TimelineEntry(1500, "Task created", null), TimelineEntry(1600, "Plan created", "1 step(s)")),
        error = null, result = "2"
    )

    @Test fun roundTripKeepsEverything() = runTest {
        val repo = TaskRepository(FakeTaskDao())
        repo.save(sample())
        val t = repo.get("t1")!!
        assertEquals(sample(), t)
        assertEquals(1, repo.tasks.first().size)
    }

    @Test fun savingAgainUpdatesInsteadOfDuplicating() = runTest {
        val repo = TaskRepository(FakeTaskDao())
        repo.save(sample()); repo.save(sample().copy(state = TaskState.FAILED, error = "x"))
        assertEquals(1, repo.tasks.first().size)
        assertEquals(TaskState.FAILED, repo.get("t1")!!.state)
    }

    @Test fun interruptedTasksAreFailedAndFinishedOnesKept() = runTest {
        val repo = TaskRepository(FakeTaskDao())
        repo.save(sample("a", TaskState.RUNNING)); repo.save(sample("b", TaskState.COMPLETED))
        assertEquals(1, repo.failInterrupted(now = 5000))
        assertEquals(TaskState.FAILED, repo.get("a")!!.state)
        assertTrue(repo.get("a")!!.error!!.startsWith("Interrupted"))
        assertEquals(TaskState.COMPLETED, repo.get("b")!!.state)
    }

    @Test fun clearFinishedKeepsActive() = runTest {
        val repo = TaskRepository(FakeTaskDao())
        repo.save(sample("a", TaskState.RUNNING)); repo.save(sample("b", TaskState.CANCELLED))
        repo.clearFinished()
        assertEquals(listOf("a"), repo.tasks.first().map { it.id })
    }

    @Test fun corruptJsonDoesNotCrash() {
        val e = sample().toEntity().copy(planJson = "{bad", stepsJson = "nope", timelineJson = "[")
        val t = e.toTask()
        assertNull(t.plan); assertTrue(t.steps.isEmpty()); assertTrue(t.timeline.isEmpty())
    }
}
