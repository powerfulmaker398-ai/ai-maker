package com.aura.ai

import com.aura.ai.data.ChatDao
import com.aura.ai.data.ChatMessageEntity
import com.aura.ai.data.secure.KeyValueStore
import com.aura.ai.data.secure.SecretStore
import com.aura.ai.domain.AIError
import com.aura.ai.domain.AIErrorType
import com.aura.ai.domain.AIProvider
import com.aura.ai.domain.AIRequest
import com.aura.ai.domain.AIResponse
import com.aura.ai.domain.AIResult
import com.aura.ai.domain.AIStreamingProvider
import com.aura.ai.domain.StreamEvent
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import com.aura.ai.agent.AgentResult
import com.aura.ai.agent.AgentRunner
import com.aura.ai.intent.IntentResult
import com.aura.ai.permissions.ConfirmationManager
import com.aura.ai.permissions.ConfirmationRequest
import com.aura.ai.task.TaskDao
import com.aura.ai.task.TaskEntity
import com.aura.ai.task.TaskState
import com.aura.ai.tools.AuraTool
import com.aura.ai.tools.ToolArgument
import com.aura.ai.tools.ToolResult
import com.aura.ai.tools.ToolRisk

class FakeDao : ChatDao {
    private val items = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    private var next = 1L
    override fun observeAll(): Flow<List<ChatMessageEntity>> = items
    override suspend fun getAll() = items.value
    override suspend fun insert(message: ChatMessageEntity): Long {
        val id = next++
        items.value = items.value + message.copy(id = id)
        return id
    }
    override suspend fun clear() { items.value = emptyList() }
}

class MemoryStore : KeyValueStore {
    val map = mutableMapOf<String, String>()
    override fun getString(key: String) = map[key]
    override fun putString(key: String, value: String?) { if (value == null) map.remove(key) else map[key] = value }
}

class MemorySecrets : SecretStore {
    var value: String? = null
    override fun get() = value
    override fun set(secret: String?) { value = secret?.takeIf { it.isNotBlank() } }
}

fun ok(text: String = "real reply", provider: String = "Test Provider") =
    AIResult.Success(AIResponse(text, provider, "test-model"))

fun fail(type: AIErrorType) = AIResult.Failure(AIError(type))

/** Returns scripted results in order; the last one repeats. */
class ScriptedProvider(vararg results: AIResult) : AIProvider {
    private val queue = results.toMutableList()
    var calls = 0
    var lastRequest: AIRequest? = null
    override val name = "Scripted"
    override suspend fun generate(request: AIRequest): AIResult {
        calls++
        lastRequest = request
        return if (queue.size > 1) queue.removeAt(0) else queue.first()
    }
}

class StreamingScripted(private val events: List<StreamEvent>) : AIStreamingProvider {
    override val name = "StreamScripted"
    override val supportsStreaming = true
    override suspend fun generate(request: AIRequest): AIResult = error("generate must not be used when streaming")
    override fun stream(request: AIRequest): Flow<StreamEvent> = flowOf(*events.toTypedArray())
}

class GatedProvider : AIProvider {
    val gate = CompletableDeferred<Unit>()
    var calls = 0
    override val name = "Gated"
    override suspend fun generate(request: AIRequest): AIResult { calls++; gate.await(); return ok() }
}

class FakeTaskDao : TaskDao {
    val items = MutableStateFlow<List<TaskEntity>>(emptyList())
    override fun observeAll(): Flow<List<TaskEntity>> = items.map { l -> l.sortedByDescending { it.createdAt } }
    override fun observe(id: String): Flow<TaskEntity?> = items.map { l -> l.firstOrNull { it.id == id } }
    override suspend fun get(id: String) = items.value.firstOrNull { it.id == id }
    override suspend fun getAll() = items.value
    override suspend fun upsert(task: TaskEntity) { items.value = items.value.filter { it.id != task.id } + task }
    override suspend fun clearFinished() {
        val done = TaskState.values().filter { it.terminal }.map { it.name }
        items.value = items.value.filter { it.state !in done }
    }
}

object NoAgent : AgentRunner {
    override suspend fun execute(userRequest: String, intent: IntentResult, onTaskCreated: (String) -> Unit): AgentResult =
        error("agent must not run")
}

class FakeConfirm(var approve: Boolean) : ConfirmationManager {
    val requests = mutableListOf<ConfirmationRequest>()
    override suspend fun confirm(request: ConfirmationRequest): Boolean { requests += request; return approve }
}

class FakeTool(
    override val name: String,
    override val risk: ToolRisk = ToolRisk.LOW,
    override val isIdempotent: Boolean = true,
    override val arguments: List<ToolArgument> = emptyList(),
    private val behavior: suspend (Int) -> ToolResult = { ToolResult.Success("ok $name") }
) : AuraTool {
    var calls = 0
    override suspend fun execute(arguments: Map<String, Any?>): ToolResult { calls++; return behavior(calls) }
}
