package com.aura.ai

import com.aura.ai.permissions.PermissionManager
import com.aura.ai.permissions.AllowAllPermissionManager
import com.aura.ai.permissions.SecurityPolicy
import com.aura.ai.agent.EventSink
import com.aura.ai.tools.*
import com.aura.ai.tools.builtin.*
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class ToolRegistryTest {
    @Test fun registerLookupListContains() {
        val r = InMemoryToolRegistry()
        assertTrue(r.register(FakeTool("tool_a")))
        assertTrue(r.contains("tool_a"))
        assertNotNull(r.get("tool_a"))
        assertEquals(1, r.list().size)
        assertTrue(r.unregister("tool_a"))
        assertNull(r.get("tool_a"))
    }
    @Test fun duplicateAndBadNamesFailSafely() {
        val r = InMemoryToolRegistry()
        val first = FakeTool("tool_a")
        assertTrue(r.register(first))
        assertFalse(r.register(FakeTool("tool_a")))
        assertSame(first, r.get("tool_a"))
        assertFalse(r.register(FakeTool("Bad Name!")))
        assertNull(r.get("delete_everything"))
    }
}

class ArgumentValidatorTest {
    private val schema = listOf(
        ToolArgument("s", ArgType.STRING), ToolArgument("n", ArgType.INTEGER, required = false),
        ToolArgument("d", ArgType.DOUBLE, required = false), ToolArgument("b", ArgType.BOOLEAN, required = false),
        ToolArgument("e", ArgType.ENUM, required = false, allowedValues = listOf("a", "b"))
    )
    @Test fun emptyArgsValidForEmptySchema() {
        assertTrue(ArgumentValidator.validate(emptyList(), emptyMap()) is ArgValidation.Valid)
    }
    @Test fun validAndCoerced() {
        val v = ArgumentValidator.validate(schema, mapOf("s" to "x", "n" to 3.0, "d" to 2, "b" to true, "e" to "a"))
        assertTrue(v is ArgValidation.Valid)
        assertEquals(3L, (v as ArgValidation.Valid).args["n"])
    }
    @Test fun missingTypeEnumAndUnexpected() {
        assertTrue(ArgumentValidator.validate(schema, emptyMap()) is ArgValidation.Invalid)
        assertTrue(ArgumentValidator.validate(schema, mapOf("s" to 5)) is ArgValidation.Invalid)
        assertTrue(ArgumentValidator.validate(schema, mapOf("s" to "x", "n" to 1.5)) is ArgValidation.Invalid)
        assertTrue(ArgumentValidator.validate(schema, mapOf("s" to "x", "e" to "zzz")) is ArgValidation.Invalid)
        assertTrue(ArgumentValidator.validate(schema, mapOf("s" to "x", "extra" to 1)) is ArgValidation.Invalid)
        assertTrue(ArgumentValidator.validate(schema, mapOf("s" to "x".repeat(2000))) is ArgValidation.Invalid)
    }
}

class SafeCalculatorTest {
    @Test fun evaluates() {
        assertEquals(110.0, SafeCalculator.evaluate("25 * 4 + 10"), 0.0)
        assertEquals(14.0, SafeCalculator.evaluate("2 + 3 * 4"), 0.0)
        assertEquals(20.0, SafeCalculator.evaluate("(2 + 3) * 4"), 0.0)
        assertEquals(-4.0, SafeCalculator.evaluate("-2^2"), 0.0)
        assertEquals(2.5, SafeCalculator.evaluate("5 / 2"), 0.0)
        assertEquals("110", SafeCalculator.format(110.0))
    }
    @Test fun rejectsAnythingThatIsNotArithmetic() {
        listOf("", "2 +", "2 + abc", "System.exit(0)", "Runtime.getRuntime().exec(\"ls\")", "1/0", "(((1)", "1".repeat(300))
            .forEach { assertThrowsCalc(it) }
    }
    private fun assertThrowsCalc(e: String) {
        try { SafeCalculator.evaluate(e); fail("should reject: $e") } catch (x: CalcException) { }
    }
    @Test fun toolReturnsResult() = runBlocking {
        val r = CalculateTool().execute(mapOf("expression" to "25 * 4 + 10"))
        assertEquals("25 * 4 + 10 = 110", (r as ToolResult.Success).summary)
        assertTrue(CalculateTool().execute(mapOf("expression" to "exec('rm')")) is ToolResult.Failure)
    }
}

class BuiltinToolsTest {
    @Test fun deviceInfoIsReadOnlyAndNonSensitive() = runBlocking {
        val r = GetDeviceInfoTool { DeviceInfo("14", 34, "Google", "Pixel") }.execute(emptyMap()) as ToolResult.Success
        assertEquals(setOf("androidVersion", "sdkInt", "manufacturer", "model"), r.data.keys)
        assertTrue(r.summary.contains("Android 14"))
    }
    @Test fun timeEchoAppInfo() = runBlocking {
        assertTrue(GetCurrentTimeTool { Instant.parse("2026-01-01T00:00:00Z") }.execute(emptyMap()) is ToolResult.Success)
        assertEquals("hi", (EchoTool().execute(mapOf("text" to "hi")) as ToolResult.Success).summary)
        assertTrue(GetAppInfoTool { AppInfo("p", "1.0", 1) }.execute(emptyMap()) is ToolResult.Success)
    }
    @Test fun confirmationDemoIsHighRiskAndNotIdempotent() {
        assertEquals(ToolRisk.HIGH, ConfirmationDemoTool().risk)
        assertFalse(ConfirmationDemoTool().isIdempotent)
    }
}

class SecurityPolicyTest {
    @Test fun riskLevels() {
        val p = SecurityPolicy()
        assertFalse(p.requiresConfirmation(ToolRisk.LOW))
        assertFalse(p.requiresConfirmation(ToolRisk.MEDIUM))
        assertTrue(p.requiresConfirmation(ToolRisk.HIGH))
        assertTrue(p.requiresConfirmation(ToolRisk.CRITICAL))
        assertTrue(SecurityPolicy(mediumRequiresConfirmation = true).requiresConfirmation(ToolRisk.MEDIUM))
    }
}

class ToolProtocolTest {
    @Test fun parsesToolCallEvenInFence() {
        val c = ToolProtocol.parseToolCall("```json\n{\"type\":\"tool_call\",\"tool\":\"get_device_info\",\"arguments\":{}}\n```")
        assertEquals("get_device_info", c?.tool)
        assertTrue(c!!.arguments.isEmpty())
    }
    @Test fun malformedCallsReturnNull() {
        assertNull(ToolProtocol.parseToolCall("run rm -rf /"))
        assertNull(ToolProtocol.parseToolCall("{\"type\":\"tool_call\"}"))
        assertNull(ToolProtocol.parseToolCall("{\"type\":\"tool_call\",\"tool\":\"x\",\"arguments\":5}"))
        assertNull(ToolProtocol.parseToolCall("{broken"))
    }
    @Test fun resultJson() {
        val ok = ToolProtocol.resultJson("calculate", ToolResult.Success("= 110", mapOf("result" to "110")))
        assertTrue(ok.contains("\"success\":true") && ok.contains("tool_result"))
        assertTrue(ToolProtocol.resultJson("x", ToolResult.Timeout).contains("\"success\":false"))
    }
}

class ToolRouterTest {
    private val sink = EventSink { }
    private fun ctx(confirm: Boolean = false) = RouteContext("t", "s1", "do it", confirm, 5_000, sink)
    private fun router(tools: List<AuraTool>, confirm: FakeConfirm = FakeConfirm(true), perms: PermissionManager = AllowAllPermissionManager()): ToolRouter {
        val reg = InMemoryToolRegistry().apply { tools.forEach { register(it) } }
        return ToolRouter(reg, SecurityPolicy(), perms, confirm)
    }

    @Test fun validTool() = runBlocking {
        val t = FakeTool("tool_a")
        assertTrue(router(listOf(t)).route(ToolCall("tool_a", emptyMap()), ctx()) is ToolResult.Success)
        assertEquals(1, t.calls)
    }
    @Test fun unknownToolRejected() = runBlocking {
        val r = router(emptyList()).route(ToolCall("delete_everything", emptyMap()), ctx())
        assertTrue(r is ToolResult.NotAvailable)
    }
    @Test fun invalidArgumentsRejectedWithoutExecuting() = runBlocking {
        val t = FakeTool("tool_a", arguments = listOf(ToolArgument("x", ArgType.INTEGER)))
        assertTrue(router(listOf(t)).route(ToolCall("tool_a", mapOf("x" to "nope")), ctx()) is ToolResult.InvalidArguments)
        assertEquals(0, t.calls)
    }
    @Test fun permissionRequired() = runBlocking {
        val t = FakeTool("tool_a")
        val deny = object : PermissionManager { override fun isGranted(tool: AuraTool) = false }
        assertTrue(router(listOf(t), perms = deny).route(ToolCall("tool_a", emptyMap()), ctx()) is ToolResult.PermissionRequired)
        assertEquals(0, t.calls)
    }
    @Test fun highRiskNeedsConfirmationAndDenialPreventsExecution() = runBlocking {
        val t = FakeTool("danger_tool", risk = ToolRisk.HIGH)
        val c = FakeConfirm(false)
        // the plan says "no confirmation needed": the policy still demands it
        val r = router(listOf(t), c).route(ToolCall("danger_tool", emptyMap()), ctx(confirm = false))
        assertTrue(r is ToolResult.Denied)
        assertEquals(1, c.requests.size)
        assertEquals(0, t.calls)
    }
    @Test fun criticalRiskAlsoNeedsConfirmationAndApprovalExecutes() = runBlocking {
        val t = FakeTool("critical_tool", risk = ToolRisk.CRITICAL)
        val c = FakeConfirm(true)
        assertTrue(router(listOf(t), c).route(ToolCall("critical_tool", emptyMap()), ctx()) is ToolResult.Success)
        assertEquals(1, c.requests.size)
        assertEquals(1, t.calls)
    }
    @Test fun toolExceptionBecomesFailure() = runBlocking {
        val t = FakeTool("tool_a") { throw IllegalStateException("secret-detail") }
        val r = router(listOf(t)).route(ToolCall("tool_a", emptyMap()), ctx())
        assertTrue(r is ToolResult.Failure)
        assertFalse((r as ToolResult.Failure).message.contains("secret-detail"))
    }
    @Test fun cancelledTaskStopsTool() = runTest {
        val started = CompletableDeferred<Unit>()
        val t = FakeTool("tool_a") { started.complete(Unit); awaitCancellation() }
        val job: Job = launch { router(listOf(t)).route(ToolCall("tool_a", emptyMap()), ctx()) }
        runCurrent()
        assertTrue(started.isCompleted)
        job.cancel()
        job.join()
        assertTrue(job.isCancelled)
    }
}
