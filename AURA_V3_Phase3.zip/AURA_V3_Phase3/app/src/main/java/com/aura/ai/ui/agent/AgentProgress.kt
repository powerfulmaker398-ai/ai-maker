package com.aura.ai.ui.agent

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aura.ai.task.StepStatus
import com.aura.ai.task.Task
import com.aura.ai.task.TaskState

fun headline(state: TaskState): String = when (state) {
    TaskState.QUEUED -> "Starting…"
    TaskState.UNDERSTANDING -> "Understanding request…"
    TaskState.PLANNING -> "Planning…"
    TaskState.WAITING_PERMISSION -> "Waiting for your approval…"
    TaskState.RUNNING, TaskState.WAITING_RESULT -> "Running…"
    TaskState.RETRYING -> "Retrying a step…"
    else -> state.name.lowercase().replace('_', ' ')
}

fun stepSymbol(s: StepStatus): String = when (s) {
    StepStatus.PENDING -> "○"
    StepStatus.RUNNING -> "⟳"
    StepStatus.DONE -> "✓"
    StepStatus.FAILED -> "✕"
    StepStatus.SKIPPED -> "–"
}

fun taskSymbol(s: TaskState): String = when (s) {
    TaskState.COMPLETED -> "✓"
    TaskState.FAILED, TaskState.TIMED_OUT -> "✕"
    TaskState.CANCELLED -> "○"
    else -> "⟳"
}

@Composable
fun AgentProgressCard(task: Task, onCancel: () -> Unit) {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.secondaryContainer,
        modifier = Modifier.widthIn(max = 320.dp)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(headline(task.state), style = MaterialTheme.typography.titleSmall)
            task.steps.forEach { s ->
                Text("${stepSymbol(s.status)} ${s.description}${s.summary?.let { " → $it" }.orEmpty()}", style = MaterialTheme.typography.bodySmall)
            }
            Text("Agent task · full timeline is in Tasks", style = MaterialTheme.typography.labelSmall)
            TextButton(onClick = onCancel) { Text("Cancel task") }
        }
    }
}
