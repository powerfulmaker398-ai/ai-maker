package com.aura.ai.domain

import kotlinx.coroutines.flow.Flow

/** Provider-independent AI contract. The rest of AURA depends only on this. */
interface AIProvider {
    /** Human-readable provider label stored with every response. */
    val name: String
    val supportsStreaming: Boolean get() = false
    suspend fun generate(request: AIRequest): AIResult
}

interface AIStreamingProvider : AIProvider {
    /** Emits real partial output from the provider, then Complete or Failed. */
    fun stream(request: AIRequest): Flow<StreamEvent>
}
