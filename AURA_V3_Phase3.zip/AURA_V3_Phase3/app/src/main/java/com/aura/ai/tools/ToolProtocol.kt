package com.aura.ai.tools

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Structured tool-call / tool-result messages. Parsed with a real JSON parser, never string matching. */
object ToolProtocol {
    /** Extracts one JSON object from model text (allows a ```json fence). Returns null if none parses. Does not alter content. */
    fun extractJsonObject(text: String): JSONObject? {
        var s = text.trim()
        if (s.startsWith("```")) s = s.removePrefix("```json").removePrefix("```JSON").removePrefix("```").trim().removeSuffix("```").trim()
        val start = s.indexOf('{')
        val end = s.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return try { JSONObject(s.substring(start, end + 1)) } catch (e: JSONException) { null }
    }

    fun toMap(o: JSONObject): Map<String, Any?> {
        val m = LinkedHashMap<String, Any?>()
        o.keys().forEach { k -> m[k] = fromJson(o.get(k)) }
        return m
    }

    private fun fromJson(v: Any?): Any? = when (v) {
        null, JSONObject.NULL -> null
        is JSONObject -> toMap(v)
        is JSONArray -> (0 until v.length()).map { fromJson(v.get(it)) }
        else -> v
    }

    /** {"type":"tool_call","tool":"name","arguments":{...}} -> ToolCall, or null if malformed. */
    fun parseToolCall(text: String): ToolCall? {
        val o = extractJsonObject(text) ?: return null
        if (o.optString("type") != "tool_call") return null
        val tool = o.optString("tool").trim()
        if (tool.isEmpty()) return null
        val args: Map<String, Any?> =
            if (o.has("arguments") && !o.isNull("arguments")) {
                toMap(o.optJSONObject("arguments") ?: return null)
            } else emptyMap()
        return ToolCall(tool, args)
    }

    fun resultJson(tool: String, result: ToolResult): String {
        val o = JSONObject().put("type", "tool_result").put("tool", tool)
        if (result is ToolResult.Success) {
            val data = JSONObject(result.data).put("summary", result.summary)
            o.put("success", true).put("result", data)
        } else {
            o.put("success", false).put("error", result.describe())
        }
        return o.toString()
    }
}
