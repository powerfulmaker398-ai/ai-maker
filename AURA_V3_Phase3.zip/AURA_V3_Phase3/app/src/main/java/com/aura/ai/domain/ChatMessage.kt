package com.aura.ai.domain

enum class Role { USER, ASSISTANT }

data class ChatMessage(
    val id: Long = 0,
    val role: Role,
    val content: String,
    val createdAt: Long = System.currentTimeMillis(),
    /** Which provider produced an ASSISTANT message (null for user messages and Phase 1 history). */
    val provider: String? = null,
    val model: String? = null
)
