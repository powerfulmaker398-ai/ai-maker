package com.aura.ai.tools

import kotlin.math.abs

enum class ToolRisk { LOW, MEDIUM, HIGH, CRITICAL }
enum class ArgType { STRING, INTEGER, DOUBLE, BOOLEAN, ENUM }

data class ToolArgument(
    val name: String,
    val type: ArgType,
    val required: Boolean = true,
    val allowedValues: List<String> = emptyList(),
    val description: String = ""
)

sealed class ToolResult {
    data class Success(val summary: String, val data: Map<String, Any?> = emptyMap()) : ToolResult()
    data class Failure(val message: String, val retryable: Boolean = false) : ToolResult()
    data class PermissionRequired(val message: String) : ToolResult()
    data class Denied(val message: String) : ToolResult()
    data object Cancelled : ToolResult()
    data object Timeout : ToolResult()
    data class InvalidArguments(val message: String) : ToolResult()
    data class NotAvailable(val message: String) : ToolResult()
}

/** Safe, human-readable text for any result (never contains secrets or stack traces). */
fun ToolResult.describe(): String = when (this) {
    is ToolResult.Success -> summary
    is ToolResult.Failure -> message
    is ToolResult.PermissionRequired -> message
    is ToolResult.Denied -> message
    ToolResult.Cancelled -> "Cancelled."
    ToolResult.Timeout -> "The tool timed out."
    is ToolResult.InvalidArguments -> "Invalid arguments: $message"
    is ToolResult.NotAvailable -> message
}

/** Tools are the ONLY way AURA acts. The AI can request a tool; it can never run code. */
interface AuraTool {
    val name: String
    val description: String
    val risk: ToolRisk
    val arguments: List<ToolArgument> get() = emptyList()
    /** Safe to repeat automatically (read-only). Side-effecting tools must return false. */
    val isIdempotent: Boolean get() = true
    suspend fun execute(arguments: Map<String, Any?>): ToolResult
}

data class ToolCall(val tool: String, val arguments: Map<String, Any?>)

sealed class ArgValidation {
    data class Valid(val args: Map<String, Any?>) : ArgValidation()
    data class Invalid(val errors: List<String>) : ArgValidation()
}

object ArgumentValidator {
    const val MAX_STRING = 1000

    fun validate(schema: List<ToolArgument>, args: Map<String, Any?>): ArgValidation {
        val errors = mutableListOf<String>()
        val out = LinkedHashMap<String, Any?>()
        val known = schema.map { it.name }.toSet()
        args.keys.filter { it !in known }.forEach { errors += "Unexpected argument '$it'" }
        for (s in schema) {
            val v = args[s.name]
            if (v == null) {
                if (s.required) errors += "Missing required argument '${s.name}'"
                continue
            }
            val (value, err) = check(s, v)
            if (err != null) errors += err else out[s.name] = value
        }
        return if (errors.isEmpty()) ArgValidation.Valid(out) else ArgValidation.Invalid(errors)
    }

    private fun check(s: ToolArgument, v: Any): Pair<Any?, String?> = when (s.type) {
        ArgType.STRING ->
            if (v is String && v.length <= MAX_STRING) Pair(v, null)
            else Pair(null, "Argument '${s.name}' must be text up to $MAX_STRING characters")
        ArgType.INTEGER -> when {
            v is Int -> Pair(v.toLong(), null)
            v is Long -> Pair(v, null)
            v is Double && v % 1.0 == 0.0 && abs(v) < 9e15 -> Pair(v.toLong(), null)
            else -> Pair(null, "Argument '${s.name}' must be an integer")
        }
        ArgType.DOUBLE ->
            if (v is Number && !v.toDouble().isNaN()) Pair(v.toDouble(), null)
            else Pair(null, "Argument '${s.name}' must be a number")
        ArgType.BOOLEAN ->
            if (v is Boolean) Pair(v, null) else Pair(null, "Argument '${s.name}' must be true or false")
        ArgType.ENUM ->
            if (v is String && v in s.allowedValues) Pair(v, null)
            else Pair(null, "Argument '${s.name}' must be one of ${s.allowedValues}")
    }
}
