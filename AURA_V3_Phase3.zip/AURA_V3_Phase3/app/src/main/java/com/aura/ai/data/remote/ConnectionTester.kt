package com.aura.ai.data.remote

import com.aura.ai.data.config.ConfigRepository
import com.aura.ai.domain.AIErrorType
import com.aura.ai.domain.AIProvider
import com.aura.ai.domain.AIProviderConfig
import com.aura.ai.domain.AIRequest
import com.aura.ai.domain.AIResult

sealed class ConnectionStatus {
    data object NotTested : ConnectionStatus()
    data object Testing : ConnectionStatus()
    data class Connected(val detail: String) : ConnectionStatus()
    data class Failed(val title: String, val detail: String) : ConnectionStatus()
}

/** Sends one real request to the SAVED cloud configuration (never to the demo provider, never via fallback). */
class ConnectionTester(
    private val config: ConfigRepository,
    private val cloudFactory: (AIProviderConfig) -> AIProvider
) {
    suspend fun test(): ConnectionStatus {
        val snap = config.snapshot.value
        if (!snap.cloudConfigured) {
            return ConnectionStatus.Failed("Invalid Configuration", "Set Base URL (https), Model and API key, then test.")
        }
        val provider = cloudFactory(config.loadProviderConfig())
        val result = provider.generate(
            AIRequest("You are a connectivity test. Reply with the single word: ok", emptyList(), "ping")
        )
        return when (result) {
            is AIResult.Success -> ConnectionStatus.Connected("The provider answered a real request (${result.response.model ?: "model"}).")
            is AIResult.Failure -> {
                val e = result.error
                when (e.type) {
                    AIErrorType.INVALID_API_KEY, AIErrorType.AUTHENTICATION_FAILED ->
                        ConnectionStatus.Failed("Authentication Failed", e.userMessage)
                    AIErrorType.NETWORK_UNAVAILABLE -> ConnectionStatus.Failed("Network Unavailable", e.userMessage)
                    AIErrorType.INVALID_CONFIGURATION -> ConnectionStatus.Failed("Invalid Configuration", e.userMessage)
                    else -> ConnectionStatus.Failed("Connection Failed", e.userMessage)
                }
            }
        }
    }
}
