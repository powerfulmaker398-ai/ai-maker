package com.aura.ai.ui.tasks

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aura.ai.task.Task
import com.aura.ai.ui.agent.stepSymbol
import com.aura.ai.ui.agent.taskSymbol
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun time(ms: Long): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(ms))
private fun dateTime(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(ms))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksScreen(viewModel: TasksViewModel, onBack: () -> Unit) {
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val selectedId by viewModel.selectedId.collectAsStateWithLifecycle()
    val selected = tasks.firstOrNull { it.id == selectedId }

    BackHandler { if (selected != null) viewModel.select(null) else onBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (selected != null) "Task" else "AURA Tasks") },
                navigationIcon = {
                    IconButton(onClick = { if (selected != null) viewModel.select(null) else onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (selected == null && tasks.any { it.state.terminal }) {
                        TextButton(onClick = viewModel::clearFinished) { Text("Clear finished") }
                    }
                }
            )
        }
    ) { padding ->
        if (selected != null) {
            TaskDetail(selected, Modifier.padding(padding))
        } else if (tasks.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("No tasks yet. Try: \"What Android version am I using?\"")
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                items(tasks, key = { it.id }) { t ->
                    Column(Modifier.fillMaxWidth().clickable { viewModel.select(t.id) }.padding(16.dp)) {
                        Text("${taskSymbol(t.state)} ${t.userRequest}", style = MaterialTheme.typography.bodyLarge, maxLines = 2)
                        Text(
                            "${t.state.name.lowercase().replace('_', ' ')} · ${dateTime(t.createdAt)}",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TaskDetail(t: Task, modifier: Modifier) {
    Column(modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Section("Request") { Text(t.userRequest) }
        Section("Status") { Text("${taskSymbol(t.state)} ${t.state.name}  ·  created ${dateTime(t.createdAt)}  ·  updated ${time(t.updatedAt)}") }
        t.plan?.let { Section("Plan: ${it.goal}") {} }
        if (t.steps.isNotEmpty()) {
            Section("Steps") {
                t.steps.forEachIndexed { i, s ->
                    Text("${stepSymbol(s.status)} ${i + 1}. ${s.description}" + (s.tool?.let { " [$it]" } ?: ""))
                    s.summary?.let { Text("    $it", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        t.result?.let { Section("Result") { Text(it) } }
        t.error?.let { Section("Error") { Text(it, color = MaterialTheme.colorScheme.error) } }
        Section("Timeline") {
            t.timeline.forEach { e ->
                Text("${time(e.time)}  ${e.label}" + (e.detail?.let { " — $it" } ?: ""), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        content()
    }
}
