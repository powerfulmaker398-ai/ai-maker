package com.aura.ai.permissions

import com.aura.ai.tools.AuraTool
import com.aura.ai.tools.ToolRisk
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Android runtime permissions a tool needs. Phase 3 tools need none; later phases plug in here. */
interface PermissionManager { fun isGranted(tool: AuraTool): Boolean }

class AllowAllPermissionManager : PermissionManager {
    override fun isGranted(tool: AuraTool) = true
}

data class ConfirmationRequest(
    val taskId: String,
    val stepId: String,
    val toolName: String,
    val description: String,
    val risk: ToolRisk
)

/** Only a human tap may approve. Nothing in the AI path can call [UiConfirmationManager.resolve]. */
interface ConfirmationManager { suspend fun confirm(request: ConfirmationRequest): Boolean }

class UiConfirmationManager : ConfirmationManager {
    private val _pending = MutableStateFlow<ConfirmationRequest?>(null)
    val pending: StateFlow<ConfirmationRequest?> = _pending.asStateFlow()
    private var deferred: CompletableDeferred<Boolean>? = null

    override suspend fun confirm(request: ConfirmationRequest): Boolean {
        val d = CompletableDeferred<Boolean>()
        synchronized(this) { deferred = d }
        _pending.value = request
        try {
            return d.await()
        } finally {
            _pending.value = null
            synchronized(this) { if (deferred === d) deferred = null }
        }
    }

    fun resolve(approved: Boolean) {
        val d = synchronized(this) { deferred }
        d?.complete(approved)
    }
}

enum class PolicyDecision { ALLOW, REQUIRE_CONFIRMATION, DENY }

/** Central security decisions. Individual tools never decide their own permissions. */
class SecurityPolicy(
    private val mediumRequiresConfirmation: Boolean = false,
    private val blockedTools: Set<String> = emptySet()
) {
    fun evaluate(tool: AuraTool): PolicyDecision = when {
        tool.name in blockedTools -> PolicyDecision.DENY
        requiresConfirmation(tool.risk) -> PolicyDecision.REQUIRE_CONFIRMATION
        else -> PolicyDecision.ALLOW
    }

    fun requiresConfirmation(risk: ToolRisk): Boolean = when (risk) {
        ToolRisk.LOW -> false
        ToolRisk.MEDIUM -> mediumRequiresConfirmation
        ToolRisk.HIGH, ToolRisk.CRITICAL -> true
    }
}
