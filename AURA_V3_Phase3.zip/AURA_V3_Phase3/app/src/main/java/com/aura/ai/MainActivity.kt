package com.aura.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.aura.ai.ui.ChatScreen
import com.aura.ai.ui.ChatViewModel
import com.aura.ai.ui.settings.SettingsScreen
import com.aura.ai.ui.settings.SettingsViewModel
import com.aura.ai.ui.tasks.TasksScreen
import com.aura.ai.ui.tasks.TasksViewModel
import com.aura.ai.ui.theme.AuraTheme
import com.aura.ai.ui.vmFactory

class MainActivity : ComponentActivity() {
    private val container get() = (application as AuraApp).container

    private val chatViewModel: ChatViewModel by viewModels {
        vmFactory {
            ChatViewModel(
                container.chatRepository, container.orchestrator, container.configRepository,
                container.taskRepository, container.confirmationManager
            )
        }
    }
    private val settingsViewModel: SettingsViewModel by viewModels {
        vmFactory {
            SettingsViewModel(container.configRepository, container.connectionTester) { container.chatRepository.clear() }
        }
    }
    private val tasksViewModel: TasksViewModel by viewModels {
        vmFactory { TasksViewModel(container.taskRepository) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AuraTheme {
                var screen by rememberSaveable { mutableStateOf("chat") }
                BackHandler(enabled = screen == "settings") { screen = "chat" }
                when (screen) {
                    "settings" -> SettingsScreen(settingsViewModel, onBack = { screen = "chat" })
                    "tasks" -> TasksScreen(tasksViewModel, onBack = { screen = "chat" })
                    else -> ChatScreen(chatViewModel, onOpenSettings = { screen = "settings" }, onOpenTasks = { screen = "tasks" })
                }
            }
        }
    }
}
