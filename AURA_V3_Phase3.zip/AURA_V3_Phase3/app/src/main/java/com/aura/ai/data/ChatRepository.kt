package com.aura.ai.data

import com.aura.ai.data.remote.SafeLog
import com.aura.ai.domain.AIError
import com.aura.ai.domain.AIErrorType
import com.aura.ai.domain.AIProvider
import com.aura.ai.domain.AIRequest
import com.aura.ai.domain.AIResult
import com.aura.ai.domain.AIStreamingProvider
import com.aura.ai.domain.ChatMessage
import com.aura.ai.domain.ContextManager
import com.aura.ai.domain.Role
import com.aura.ai.domain.StreamEvent
import com.aura.ai.domain.SystemPrompts
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ChatRepository(
    private val dao: ChatDao,
    private val providerSource: () -> AIProvider,
    private val maxContextSource: () -> Int = { 20 },
    private val maxAttempts: Int = 3,
    private val retryDelayMs: Long = 1_000L
) {
    val messages: Flow<List<ChatMessage>> = dao.observeAll().map { list -> list.map { it.toDomain() } }

    /**
     * Saves the user message, then asks the provider. An assistant message is saved ONLY on a real,
     * validated success. On failure the user message stays and the error is returned.
     */
    suspend fun send(text: String, onPartial: (String) -> Unit = {}): AIResult {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return failure(AIErrorType.INVALID_INPUT)
        dao.insert(ChatMessage(role = Role.USER, content = trimmed).toEntity())
        return respond(onPartial)
    }

    /** Re-asks for a reply to the last user message without saving it again. */
    suspend fun retry(onPartial: (String) -> Unit = {}): AIResult {
        val last = dao.getAll().lastOrNull()
        if (last == null || last.role != Role.USER.name) return failure(AIErrorType.INVALID_INPUT)
        return respond(onPartial)
    }

    suspend fun clear() = dao.clear()

    /** Used by the agent path, which stores the user message itself. */
    suspend fun saveUserMessage(text: String) {
        dao.insert(ChatMessage(role = Role.USER, content = text.trim()).toEntity())
    }

    suspend fun saveAssistantMessage(text: String, provider: String, model: String? = null) {
        dao.insert(ChatMessage(role = Role.ASSISTANT, content = text, provider = provider, model = model).toEntity())
    }

    private suspend fun respond(onPartial: (String) -> Unit): AIResult {
        val history = dao.getAll().map { it.toDomain() }
        val pending = history.last()
        val request = AIRequest(
            systemPrompt = SystemPrompts.AURA,
            conversation = ContextManager.select(history.dropLast(1), maxContextSource()),
            userInput = pending.content
        )
        val provider = providerSource()
        var attempt = 0
        while (true) {
            attempt++
            if (attempt > 1) onPartial("")
            when (val result = attemptOnce(provider, request, onPartial)) {
                is AIResult.Success -> {
                    val r = result.response
                    if (r.text.isBlank()) return failure(AIErrorType.EMPTY_RESPONSE, r.provider)
                    dao.insert(
                        ChatMessage(role = Role.ASSISTANT, content = r.text, provider = r.provider, model = r.model).toEntity()
                    )
                    return result
                }
                is AIResult.Failure -> {
                    if (result.error.retryable && attempt < maxAttempts) {
                        SafeLog.d("Retrying attempt=${attempt + 1} type=${result.error.type}")
                        delay(retryDelayMs * attempt)
                    } else return result
                }
            }
        }
    }

    private suspend fun attemptOnce(provider: AIProvider, request: AIRequest, onPartial: (String) -> Unit): AIResult =
        try {
            if (provider is AIStreamingProvider && provider.supportsStreaming) {
                collectStream(provider, request, onPartial)
            } else provider.generate(request)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            SafeLog.w("Provider threw ${e.javaClass.simpleName}")
            failure(AIErrorType.UNKNOWN, provider.name)
        }

    private suspend fun collectStream(p: AIStreamingProvider, request: AIRequest, onPartial: (String) -> Unit): AIResult {
        val sb = StringBuilder()
        var result: AIResult? = null
        p.stream(request).collect { ev ->
            when (ev) {
                is StreamEvent.Delta -> { sb.append(ev.text); onPartial(sb.toString()) }
                is StreamEvent.Complete -> result = AIResult.Success(ev.response)
                is StreamEvent.Failed -> result = AIResult.Failure(ev.error)
            }
        }
        return result ?: failure(AIErrorType.INVALID_RESPONSE, p.name)
    }

    private fun failure(type: AIErrorType, provider: String? = null) =
        AIResult.Failure(AIError(type, provider = provider))
}
