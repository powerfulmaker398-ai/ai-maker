package com.aura.ai.domain

/** Limits how much history is sent to a provider. Future: summarization hooks in here. */
object ContextManager {
    const val DEFAULT_MAX_CHARS = 16_000

    fun select(history: List<ChatMessage>, maxMessages: Int, maxChars: Int = DEFAULT_MAX_CHARS): List<AIMessage> {
        val recent = history.takeLast(maxMessages.coerceAtLeast(0))
        val out = ArrayDeque<AIMessage>()
        var total = 0
        for (m in recent.asReversed()) {
            val remaining = maxChars - total
            if (remaining <= 0) break
            val content = if (m.content.length > remaining) {
                if (out.isNotEmpty()) break else m.content.take(remaining)
            } else m.content
            out.addFirst(AIMessage(m.role, content))
            total += content.length
        }
        return out.toList()
    }
}
