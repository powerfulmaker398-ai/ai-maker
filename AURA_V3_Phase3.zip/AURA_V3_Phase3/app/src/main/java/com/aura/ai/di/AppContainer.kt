package com.aura.ai.di

import android.content.Context
import com.aura.ai.data.AuraDatabase
import com.aura.ai.data.ChatRepository
import com.aura.ai.data.config.ConfigRepository
import com.aura.ai.data.remote.AIProviderFactory
import com.aura.ai.data.remote.AndroidNetworkMonitor
import com.aura.ai.data.remote.ConnectionTester
import com.aura.ai.data.secure.KeystoreSecretStore
import com.aura.ai.data.secure.SharedPrefsStore
import com.aura.ai.agent.AIAgentResponder
import com.aura.ai.agent.AgentConfig
import com.aura.ai.agent.AgentEngine
import com.aura.ai.agent.AuraOrchestrator
import com.aura.ai.domain.DemoAIProvider
import com.aura.ai.intent.AIIntentClassifier
import com.aura.ai.intent.HeuristicIntentClassifier
import com.aura.ai.intent.HybridIntentClassifier
import com.aura.ai.permissions.AllowAllPermissionManager
import com.aura.ai.permissions.SecurityPolicy
import com.aura.ai.permissions.UiConfirmationManager
import com.aura.ai.planner.AIPlanner
import com.aura.ai.planner.HybridPlanner
import com.aura.ai.planner.RuleBasedPlanner
import com.aura.ai.task.TaskRepository
import com.aura.ai.tools.InMemoryToolRegistry
import com.aura.ai.tools.ToolRegistry
import com.aura.ai.tools.ToolRouter
import com.aura.ai.tools.builtin.AppInfo
import com.aura.ai.tools.builtin.DeviceInfo
import com.aura.ai.tools.builtin.builtinTools
import androidx.core.content.pm.PackageInfoCompat
import android.os.Build
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Manual dependency wiring: Application -> container -> repositories -> ViewModels. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    private val database by lazy { AuraDatabase.create(appContext) }
    private val networkMonitor by lazy { AndroidNetworkMonitor(appContext) }
    private val demoProvider by lazy { DemoAIProvider() }

    val configRepository by lazy {
        ConfigRepository(
            store = SharedPrefsStore(appContext, "aura_config"),
            secrets = KeystoreSecretStore(SharedPrefsStore(appContext, "aura_secrets"))
        )
    }

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(false) // retries are explicit and bounded in ChatRepository
            .build() // no logging interceptor on purpose
    }

    private val providerFactory by lazy { AIProviderFactory(configRepository, httpClient, networkMonitor, demoProvider) }

    val chatRepository by lazy {
        ChatRepository(
            dao = database.chatDao(),
            providerSource = { providerFactory.current() },
            maxContextSource = { configRepository.snapshot.value.maxContextMessages }
        )
    }

    val connectionTester by lazy { ConnectionTester(configRepository) { cfg -> providerFactory.cloud(cfg, streaming = false) } }

    // ---- Phase 3: agent ----
    private val agentConfig = AgentConfig()
    private val securityPolicy = SecurityPolicy()
    private val providerSource: () -> com.aura.ai.domain.AIProvider = { providerFactory.current() }

    val taskRepository by lazy { TaskRepository(database.taskDao()) }
    val confirmationManager by lazy { UiConfirmationManager() }

    val toolRegistry: ToolRegistry by lazy {
        InMemoryToolRegistry().also { registry ->
            builtinTools(
                deviceInfo = { DeviceInfo(Build.VERSION.RELEASE.orEmpty(), Build.VERSION.SDK_INT, Build.MANUFACTURER.orEmpty(), Build.MODEL.orEmpty()) },
                appInfo = {
                    try {
                        val info = appContext.packageManager.getPackageInfo(appContext.packageName, 0)
                        AppInfo(appContext.packageName, info.versionName ?: "unknown", PackageInfoCompat.getLongVersionCode(info))
                    } catch (e: Exception) {
                        AppInfo(appContext.packageName, "unknown", 0)
                    }
                }
            ).forEach { registry.register(it) }
        }
    }

    private val toolRouter by lazy { ToolRouter(toolRegistry, securityPolicy, AllowAllPermissionManager(), confirmationManager) }

    private val agentEngine by lazy {
        AgentEngine(
            planner = HybridPlanner(providerSource, AIPlanner(providerSource, toolRegistry, agentConfig.maxSteps), RuleBasedPlanner()),
            router = toolRouter, registry = toolRegistry, policy = securityPolicy, tasks = taskRepository,
            responder = AIAgentResponder(providerSource), config = agentConfig
        )
    }

    val orchestrator by lazy {
        AuraOrchestrator(
            HybridIntentClassifier(HeuristicIntentClassifier(), AIIntentClassifier(providerSource), providerSource),
            agentEngine, chatRepository
        )
    }
}
