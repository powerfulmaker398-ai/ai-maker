package com.aura.ai.tools.builtin

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.pow

class CalcException(message: String) : Exception(message)

/**
 * Controlled arithmetic parser: numbers, + - * / % ^, unary +/-, parentheses. Nothing else is accepted,
 * so no code can run through it.
 */
object SafeCalculator {
    const val MAX_LENGTH = 200
    private const val MAX_DEPTH = 50

    fun evaluate(input: String): Double {
        val s = input.trim()
        if (s.isEmpty() || s.length > MAX_LENGTH) throw CalcException("Expression is empty or too long.")
        val p = Parser(s)
        val v = p.expression()
        p.expectEnd()
        if (v.isNaN() || v.isInfinite()) throw CalcException("Result is not a finite number.")
        return v
    }

    fun format(v: Double): String =
        if (v == floor(v) && abs(v) < 1e15) v.toLong().toString()
        else BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()

    private class Parser(private val s: String) {
        private var pos = 0
        private var depth = 0

        private fun peek(): Char? {
            while (pos < s.length && s[pos].isWhitespace()) pos++
            return if (pos < s.length) s[pos] else null
        }

        fun expectEnd() { if (peek() != null) throw CalcException("Unexpected character '${s[pos]}'.") }

        fun expression(): Double {
            var v = term()
            while (true) {
                when (peek()) {
                    '+' -> { pos++; v += term() }
                    '-' -> { pos++; v -= term() }
                    else -> return v
                }
            }
        }

        private fun term(): Double {
            var v = unary()
            while (true) {
                when (peek()) {
                    '*' -> { pos++; v *= unary() }
                    '/' -> { pos++; val d = unary(); if (d == 0.0) throw CalcException("Division by zero."); v /= d }
                    '%' -> { pos++; val d = unary(); if (d == 0.0) throw CalcException("Division by zero."); v %= d }
                    else -> return v
                }
            }
        }

        private fun unary(): Double = when (peek()) {
            '-' -> { pos++; -unary() }
            '+' -> { pos++; unary() }
            else -> power()
        }

        private fun power(): Double {
            val base = primary()
            if (peek() == '^') { pos++; return base.pow(unary()) }
            return base
        }

        private fun primary(): Double {
            val c = peek() ?: throw CalcException("Unexpected end of expression.")
            if (c == '(') {
                pos++
                if (++depth > MAX_DEPTH) throw CalcException("Expression is nested too deeply.")
                val v = expression()
                if (peek() != ')') throw CalcException("Missing closing parenthesis.")
                pos++; depth--
                return v
            }
            if (c.isDigit() || c == '.') {
                val start = pos
                while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
                return s.substring(start, pos).toDoubleOrNull() ?: throw CalcException("Invalid number.")
            }
            throw CalcException("Unexpected character '$c'.")
        }
    }
}
