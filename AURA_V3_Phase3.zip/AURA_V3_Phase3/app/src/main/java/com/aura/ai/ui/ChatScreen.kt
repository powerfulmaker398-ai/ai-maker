package com.aura.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aura.ai.domain.ChatMessage
import com.aura.ai.domain.Role
import com.aura.ai.ui.agent.AgentProgressCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: ChatViewModel, onOpenSettings: () -> Unit, onOpenTasks: () -> Unit) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    var confirmClear by rememberSaveable { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val pending by viewModel.pendingConfirmation.collectAsStateWithLifecycle()
    val itemCount = state.messages.size + if (state.isBusy) 1 else 0

    LaunchedEffect(itemCount, state.partialText?.length) {
        if (itemCount > 0) listState.scrollToItem(itemCount - 1)
    }

    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AURA", style = MaterialTheme.typography.titleLarge)
                        Text(state.providerLabel, style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    IconButton(onClick = { confirmClear = true }, enabled = state.messages.isNotEmpty() && !state.isBusy) {
                        Icon(Icons.Default.Delete, contentDescription = "Clear conversation")
                    }
                    TextButton(onClick = onOpenTasks) { Text("Tasks") }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        bottomBar = {
            Column(Modifier.padding(8.dp)) {
                state.error?.let {
                    Text(it.userMessage, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 4.dp))
                }
                if (!state.isBusy && state.canRetry) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (state.error == null) {
                            Text("Your last message has no reply yet.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        } else Box(Modifier.weight(1f))
                        TextButton(onClick = viewModel::retry) { Text("Retry") }
                        if (state.error != null) TextButton(onClick = viewModel::dismissError) { Text("Dismiss") }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        placeholder = { Text("Talk to AURA...") },
                        modifier = Modifier.weight(1f),
                        maxLines = 4
                    )
                    if (state.isBusy) {
                        IconButton(onClick = viewModel::cancel) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel generation")
                        }
                    } else {
                        IconButton(onClick = { viewModel.send(input); input = "" }, enabled = input.isNotBlank()) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                        }
                    }
                }
            }
        }
    ) { padding ->
        if (state.messages.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("No messages yet. Say hello to AURA.", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(state.messages, key = { it.id }) { MessageBubble(it) }
                if (state.isBusy) item(key = "pending") {
                    val task = state.agentTask
                    if (task != null) AgentProgressCard(task, onCancel = viewModel::cancel) else PendingBubble(state.partialText)
                }
            }
        }
    }

    pending?.let { req ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("AURA wants to run an action") },
            text = {
                Column {
                    Text(req.description)
                    Text("Tool: ${req.toolName}", style = MaterialTheme.typography.bodySmall)
                    Text("Risk: ${req.risk}", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { viewModel.resolveConfirmation(true) }) { Text("Approve") } },
            dismissButton = { TextButton(onClick = { viewModel.resolveConfirmation(false) }) { Text("Cancel") } }
        )
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear conversation?") },
            text = { Text("This permanently deletes all saved messages.") },
            confirmButton = { TextButton(onClick = { viewModel.clear(); confirmClear = false }) { Text("Clear") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == Role.USER
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
        Surface(
            shape = MaterialTheme.shapes.large,
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Text(message.content, Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
        }
        if (!isUser && message.provider != null) {
            val model = message.model?.let { " · $it" }.orEmpty()
            Text("Provider: ${message.provider}$model", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 4.dp, top = 2.dp))
        }
    }
}

@Composable
private fun PendingBubble(partial: String?) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
        Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Text(partial ?: "Thinking…", Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
        }
        Text(
            if (partial == null) "Waiting for the provider…" else "Streaming from the provider…",
            style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 4.dp, top = 2.dp)
        )
    }
}
