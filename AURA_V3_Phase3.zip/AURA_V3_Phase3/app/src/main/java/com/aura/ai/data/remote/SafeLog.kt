package com.aura.ai.data.remote

import android.util.Log

/** Logging that only accepts short event descriptions. Callers must never pass keys, headers or message text. */
object SafeLog {
    private const val TAG = "AURA"
    fun d(msg: String) { try { Log.d(TAG, msg) } catch (e: RuntimeException) { /* JVM unit tests */ } }
    fun w(msg: String) { try { Log.w(TAG, msg) } catch (e: RuntimeException) { /* JVM unit tests */ } }
}
