package com.aura.ai.domain

import java.net.URI
import java.net.URISyntaxException

data class AIProviderConfig(
    val providerName: String,
    val baseUrl: String,
    val model: String,
    val apiKey: String?
) {
    /** Never prints the key. */
    override fun toString() =
        "AIProviderConfig(providerName=$providerName, baseUrl=$baseUrl, model=$model, apiKey=${if (apiKey.isNullOrBlank()) "none" else "***"})"

    fun validationError(requireKey: Boolean = true): String? {
        if (providerName.isBlank()) return "Provider name is required."
        baseUrlError(baseUrl)?.let { return it }
        if (model.isBlank()) return "Model is required."
        if (requireKey && apiKey.isNullOrBlank()) return "API key is required."
        return null
    }

    companion object {
        fun baseUrlError(url: String): String? = try {
            val u = URI(url.trim())
            if (u.scheme?.lowercase() != "https" || u.host.isNullOrBlank()) "Base URL must start with https://" else null
        } catch (e: URISyntaxException) {
            "Base URL is not a valid URL."
        }
    }
}

/** UI-safe view of configuration. Contains no secret, only whether a key exists. */
data class ConfigSnapshot(
    val providerName: String,
    val baseUrl: String,
    val model: String,
    val hasApiKey: Boolean,
    val maxContextMessages: Int,
    val streamingEnabled: Boolean,
    val demoFallbackEnabled: Boolean
) {
    val cloudConfigured: Boolean
        get() = baseUrl.isNotBlank() && model.isNotBlank() && hasApiKey &&
            AIProviderConfig.baseUrlError(baseUrl) == null
}
