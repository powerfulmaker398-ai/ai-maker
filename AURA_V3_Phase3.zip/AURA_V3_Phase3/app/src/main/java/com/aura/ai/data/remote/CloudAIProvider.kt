package com.aura.ai.data.remote

import com.aura.ai.domain.AIError
import com.aura.ai.domain.AIErrorType
import com.aura.ai.domain.AIProviderConfig
import com.aura.ai.domain.AIRequest
import com.aura.ai.domain.AIResponse
import com.aura.ai.domain.AIResult
import com.aura.ai.domain.AIStreamingProvider
import com.aura.ai.domain.StreamEvent
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.SendChannel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONException
import java.io.IOException
import java.io.InterruptedIOException
import javax.net.ssl.SSLException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Cloud provider speaking the common "chat completions" HTTP format (endpoint: <baseUrl>/chat/completions,
 * header "Authorization: Bearer <key>"). Not tied to one vendor: base URL, model and key are configuration.
 * Secrets are only placed in the Authorization header and are never logged.
 */
class CloudAIProvider(
    private val config: AIProviderConfig,
    private val client: OkHttpClient,
    private val network: NetworkMonitor,
    private val streamingEnabled: Boolean = true,
    private val io: CoroutineDispatcher = Dispatchers.IO
) : AIStreamingProvider {

    override val name: String = "Cloud AI · ${config.providerName}"
    override val supportsStreaming: Boolean get() = streamingEnabled

    private fun error(type: AIErrorType) = AIError(type, provider = name)
    private fun fail(type: AIErrorType) = AIResult.Failure(error(type))

    private fun buildHttpRequest(request: AIRequest, stream: Boolean): Request? {
        val key = config.apiKey
        if (key.isNullOrBlank() || config.model.isBlank()) return null
        val url = OpenAiCompat.chatUrl(config.baseUrl).toHttpUrlOrNull() ?: return null
        return Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $key")
            .header("Accept", if (stream) "text/event-stream" else "application/json")
            .post(OpenAiCompat.buildBody(config.model, request, stream).toRequestBody(JSON))
            .build()
    }

    override suspend fun generate(request: AIRequest): AIResult = withContext(io) {
        if (!network.isOnline()) return@withContext fail(AIErrorType.NETWORK_UNAVAILABLE)
        val http = buildHttpRequest(request, stream = false) ?: return@withContext fail(AIErrorType.INVALID_CONFIGURATION)
        SafeLog.d("AI request started provider=$name")
        try {
            val result: AIResult = client.newCall(http).await().use { response ->
                if (!response.isSuccessful) {
                    AIResult.Failure(mapStatus(response.code))
                } else {
                    val text = response.body?.string()
                    if (text.isNullOrBlank()) fail(AIErrorType.INVALID_RESPONSE)
                    else OpenAiCompat.parseCompletion(text, name, config.model)
                }
            }
            SafeLog.d(if (result is AIResult.Success) "AI request completed provider=$name" else "AI request failed provider=$name type=${(result as AIResult.Failure).error.type}")
            result
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            AIResult.Failure(mapIo(e))
        } catch (e: Exception) {
            fail(AIErrorType.UNKNOWN)
        }
    }

    override fun stream(request: AIRequest): Flow<StreamEvent> = channelFlow {
        val out: SendChannel<StreamEvent> = this
        if (!network.isOnline()) { send(StreamEvent.Failed(error(AIErrorType.NETWORK_UNAVAILABLE))); return@channelFlow }
        val http = buildHttpRequest(request, stream = true)
        if (http == null) { send(StreamEvent.Failed(error(AIErrorType.INVALID_CONFIGURATION))); return@channelFlow }
        SafeLog.d("AI stream started provider=$name")
        val call = client.newCall(http)
        launch(io) {
            readStream(out, call)
            out.close()
        }
        awaitClose { call.cancel() }
    }

    private suspend fun readStream(out: SendChannel<StreamEvent>, call: Call) {
        try {
            call.execute().use { response ->
                if (!response.isSuccessful) { out.send(StreamEvent.Failed(mapStatus(response.code))); return }
                val source = response.body?.source()
                if (source == null) { out.send(StreamEvent.Failed(error(AIErrorType.INVALID_RESPONSE))); return }
                val sb = StringBuilder()
                while (true) {
                    val line = source.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val data = line.removePrefix("data:").trim()
                    if (data.isEmpty()) continue
                    if (data == "[DONE]") break
                    val delta = try {
                        OpenAiCompat.parseStreamDelta(data)
                    } catch (e: JSONException) {
                        out.send(StreamEvent.Failed(error(AIErrorType.INVALID_RESPONSE))); return
                    }
                    if (delta.isNotEmpty()) { sb.append(delta); out.send(StreamEvent.Delta(delta)) }
                }
                if (sb.isBlank()) out.send(StreamEvent.Failed(error(AIErrorType.EMPTY_RESPONSE)))
                else out.send(StreamEvent.Complete(AIResponse(sb.toString(), name, config.model)))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            out.trySend(StreamEvent.Failed(mapIo(e)))
        } catch (e: Exception) {
            out.trySend(StreamEvent.Failed(error(AIErrorType.UNKNOWN)))
        }
    }

    /** Maps an HTTP status to a safe error. The response body is deliberately never read or shown. */
    private fun mapStatus(code: Int): AIError = when (code) {
        401 -> error(AIErrorType.INVALID_API_KEY)
        403 -> error(AIErrorType.AUTHENTICATION_FAILED)
        400, 404, 422 -> AIError(
            AIErrorType.INVALID_CONFIGURATION,
            "The provider rejected the request (HTTP $code). Check Base URL and model name.", provider = name
        )
        408 -> error(AIErrorType.TIMEOUT)
        429 -> error(AIErrorType.RATE_LIMITED)
        in 500..599 -> error(AIErrorType.SERVER_ERROR)
        else -> AIError(AIErrorType.UNKNOWN, "Unexpected response from the provider (HTTP $code).", provider = name)
    }

    private fun mapIo(e: IOException): AIError = when (e) {
        is InterruptedIOException -> error(AIErrorType.TIMEOUT) // includes SocketTimeoutException
        is SSLException -> AIError(
            AIErrorType.NETWORK_UNAVAILABLE, "Secure connection failed. Check the Base URL.", provider = name
        )
        else -> error(AIErrorType.NETWORK_UNAVAILABLE)
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        val call = this
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }
            override fun onResponse(call: Call, response: Response) {
                if (cont.isActive) cont.resume(response) else response.close()
            }
        })
    }

    private companion object {
        val JSON = "application/json; charset=utf-8".toMediaType()
    }
}
