package com.aura.ai.domain

data class AIMessage(val role: Role, val content: String)

data class AIRequest(
    val systemPrompt: String,
    val conversation: List<AIMessage>,
    val userInput: String,
    val temperature: Double? = null,
    val maxOutputTokens: Int? = null
)

data class AIResponse(val text: String, val provider: String, val model: String? = null)

enum class AIErrorType(val defaultMessage: String, val retryable: Boolean) {
    NETWORK_UNAVAILABLE("No internet connection.", true),
    AUTHENTICATION_FAILED("Authentication failed. Check your API key and account access.", false),
    INVALID_API_KEY("The API key was rejected. Check it in Settings.", false),
    RATE_LIMITED("The provider is rate limiting requests. Try again shortly.", true),
    TIMEOUT("AI request timed out.", true),
    SERVER_ERROR("The AI provider had a server error.", true),
    INVALID_RESPONSE("The AI provider returned a response AURA could not read.", false),
    EMPTY_RESPONSE("The AI provider returned an empty response.", false),
    INVALID_CONFIGURATION("The AI configuration is invalid. Check Base URL, model and API key in Settings.", false),
    INVALID_INPUT("Nothing to send.", false),
    CANCELLED("Cancelled.", false),
    UNKNOWN("Something went wrong.", false)
}

/** [userMessage] is always safe to display: it never contains keys, headers or raw server bodies. */
data class AIError(
    val type: AIErrorType,
    val userMessage: String = type.defaultMessage,
    val retryable: Boolean = type.retryable,
    val provider: String? = null
)

sealed class AIResult {
    data class Success(val response: AIResponse) : AIResult()
    data class Failure(val error: AIError) : AIResult()
}

sealed class StreamEvent {
    data class Delta(val text: String) : StreamEvent()
    data class Complete(val response: AIResponse) : StreamEvent()
    data class Failed(val error: AIError) : StreamEvent()
}
