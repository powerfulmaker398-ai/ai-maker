package com.aura.ai.task

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import com.aura.ai.planner.Plan
import com.aura.ai.planner.PlanStep
import com.aura.ai.tools.ToolProtocol
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val userRequest: String,
    val goal: String,
    val state: String,
    val createdAt: Long,
    val updatedAt: Long,
    val planJson: String?,
    val stepsJson: String,
    val timelineJson: String,
    val currentStep: Int,
    val error: String?,
    val result: String?
)

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    fun observe(id: String): Flow<TaskEntity?>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun get(id: String): TaskEntity?

    @Query("SELECT * FROM tasks")
    suspend fun getAll(): List<TaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE state IN ('COMPLETED','FAILED','CANCELLED','TIMED_OUT')")
    suspend fun clearFinished()
}

/** JSON (de)serialization for the structured parts of a task. Decoding never throws. */
object TaskJson {
    fun plan(p: Plan?): String? = p?.let {
        val steps = JSONArray()
        it.steps.forEach { s ->
            steps.put(
                JSONObject().put("id", s.id).put("description", s.description)
                    .put("tool", s.toolName ?: JSONObject.NULL)
                    .put("arguments", JSONObject(s.arguments))
                    .put("requiresConfirmation", s.requiresConfirmation)
            )
        }
        JSONObject().put("id", it.id).put("goal", it.goal).put("steps", steps).toString()
    }

    fun planFrom(json: String?): Plan? = try {
        if (json == null) null else {
            val o = JSONObject(json)
            val arr = o.getJSONArray("steps")
            Plan(o.getString("id"), o.getString("goal"), (0 until arr.length()).map { i ->
                val s = arr.getJSONObject(i)
                PlanStep(
                    s.getString("id"), s.getString("description"),
                    if (s.isNull("tool")) null else s.getString("tool"),
                    ToolProtocol.toMap(s.getJSONObject("arguments")),
                    s.optBoolean("requiresConfirmation", false)
                )
            })
        }
    } catch (e: JSONException) { null }

    fun steps(l: List<StepRecord>): String {
        val arr = JSONArray()
        l.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("description", it.description)
                    .put("tool", it.tool ?: JSONObject.NULL).put("status", it.status.name)
                    .put("summary", it.summary ?: JSONObject.NULL)
            )
        }
        return arr.toString()
    }

    fun stepsFrom(json: String): List<StepRecord> = try {
        val arr = JSONArray(json)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            StepRecord(
                o.getString("id"), o.getString("description"),
                if (o.isNull("tool")) null else o.getString("tool"),
                runCatching { StepStatus.valueOf(o.getString("status")) }.getOrDefault(StepStatus.PENDING),
                if (o.isNull("summary")) null else o.getString("summary")
            )
        }
    } catch (e: JSONException) { emptyList() }

    fun timeline(l: List<TimelineEntry>): String {
        val arr = JSONArray()
        l.forEach {
            arr.put(JSONObject().put("t", it.time).put("label", it.label).put("detail", it.detail ?: JSONObject.NULL))
        }
        return arr.toString()
    }

    fun timelineFrom(json: String): List<TimelineEntry> = try {
        val arr = JSONArray(json)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            TimelineEntry(o.getLong("t"), o.getString("label"), if (o.isNull("detail")) null else o.getString("detail"))
        }
    } catch (e: JSONException) { emptyList() }
}

fun Task.toEntity() = TaskEntity(
    id, userRequest, goal, state.name, createdAt, updatedAt, TaskJson.plan(plan),
    TaskJson.steps(steps), TaskJson.timeline(timeline), currentStep, error, result
)

fun TaskEntity.toTask() = Task(
    id, userRequest, goal,
    runCatching { TaskState.valueOf(state) }.getOrDefault(TaskState.FAILED),
    createdAt, updatedAt, TaskJson.planFrom(planJson), TaskJson.stepsFrom(stepsJson),
    currentStep, TaskJson.timelineFrom(timelineJson), error, result
)

class TaskRepository(private val dao: TaskDao) {
    val tasks: Flow<List<Task>> = dao.observeAll().map { l -> l.map { it.toTask() } }
    fun observe(id: String): Flow<Task?> = dao.observe(id).map { it?.toTask() }
    suspend fun get(id: String): Task? = dao.get(id)?.toTask()
    suspend fun save(task: Task) = dao.upsert(task.toEntity())
    suspend fun clearFinished() = dao.clearFinished()

    /** Tasks left unfinished by a closed app can never resume: mark them FAILED honestly. */
    suspend fun failInterrupted(now: Long = System.currentTimeMillis()): Int {
        val stale = dao.getAll().map { it.toTask() }.filter { !it.state.terminal }
        stale.forEach {
            save(
                it.copy(
                    state = TaskState.FAILED, updatedAt = now,
                    error = "Interrupted: AURA was closed before this task finished.",
                    timeline = it.timeline + TimelineEntry(now, "Task interrupted", "App was closed")
                )
            )
        }
        return stale.size
    }
}
