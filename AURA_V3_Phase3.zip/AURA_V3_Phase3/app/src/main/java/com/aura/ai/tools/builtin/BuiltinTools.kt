package com.aura.ai.tools.builtin

import com.aura.ai.tools.ArgType
import com.aura.ai.tools.AuraTool
import com.aura.ai.tools.ToolArgument
import com.aura.ai.tools.ToolResult
import com.aura.ai.tools.ToolRisk
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

object ToolNames {
    const val TIME = "get_current_time"
    const val APP_INFO = "get_app_info"
    const val DEVICE_INFO = "get_device_info"
    const val ECHO = "echo"
    const val CALCULATE = "calculate"
    const val CONFIRM_DEMO = "demo_confirmation_action"
}

/** Non-sensitive only: no identifiers, accounts or advertising IDs. */
data class DeviceInfo(val androidVersion: String, val sdkInt: Int, val manufacturer: String, val model: String)
data class AppInfo(val packageName: String, val versionName: String, val versionCode: Long)

class GetCurrentTimeTool(private val clock: () -> Instant = { Instant.now() }) : AuraTool {
    override val name = ToolNames.TIME
    override val description = "Returns the current date and time on this device."
    override val risk = ToolRisk.LOW
    override suspend fun execute(arguments: Map<String, Any?>): ToolResult {
        val now: ZonedDateTime = clock().atZone(ZoneId.systemDefault())
        val text = now.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME)
        return ToolResult.Success("Current time: $text", mapOf("iso" to text, "epochMillis" to now.toInstant().toEpochMilli()))
    }
}

class GetAppInfoTool(private val info: () -> AppInfo) : AuraTool {
    override val name = ToolNames.APP_INFO
    override val description = "Returns AURA's package name and version."
    override val risk = ToolRisk.LOW
    override suspend fun execute(arguments: Map<String, Any?>): ToolResult {
        val i = info()
        return ToolResult.Success(
            "AURA ${i.versionName} (build ${i.versionCode}, ${i.packageName})",
            mapOf("packageName" to i.packageName, "versionName" to i.versionName, "versionCode" to i.versionCode)
        )
    }
}

class GetDeviceInfoTool(private val info: () -> DeviceInfo) : AuraTool {
    override val name = ToolNames.DEVICE_INFO
    override val description = "Returns Android version, SDK level, manufacturer and model (read-only, non-sensitive)."
    override val risk = ToolRisk.LOW
    override suspend fun execute(arguments: Map<String, Any?>): ToolResult {
        val d = info()
        return ToolResult.Success(
            "Android ${d.androidVersion} (SDK ${d.sdkInt}), ${d.manufacturer} ${d.model}",
            mapOf("androidVersion" to d.androidVersion, "sdkInt" to d.sdkInt, "manufacturer" to d.manufacturer, "model" to d.model)
        )
    }
}

class EchoTool : AuraTool {
    override val name = ToolNames.ECHO
    override val description = "Returns the given text unchanged (test tool)."
    override val risk = ToolRisk.LOW
    override val arguments = listOf(ToolArgument("text", ArgType.STRING, description = "Text to echo"))
    override suspend fun execute(arguments: Map<String, Any?>): ToolResult {
        val text = arguments["text"] as String
        return ToolResult.Success(text, mapOf("text" to text))
    }
}

class CalculateTool : AuraTool {
    override val name = ToolNames.CALCULATE
    override val description = "Evaluates an arithmetic expression using + - * / % ^ and parentheses."
    override val risk = ToolRisk.LOW
    override val arguments = listOf(ToolArgument("expression", ArgType.STRING, description = "e.g. 25 * 4 + 10"))
    override suspend fun execute(arguments: Map<String, Any?>): ToolResult {
        val expr = arguments["expression"] as String
        return try {
            val shown = SafeCalculator.format(SafeCalculator.evaluate(expr))
            ToolResult.Success("${expr.trim()} = $shown", mapOf("expression" to expr.trim(), "result" to shown))
        } catch (e: CalcException) {
            ToolResult.Failure("Cannot calculate: ${e.message}")
        }
    }
}

/** HIGH-risk test tool with NO real effect. It exists to exercise the confirmation flow. */
class ConfirmationDemoTool : AuraTool {
    override val name = ToolNames.CONFIRM_DEMO
    override val description = "Harmless demo action that requires user confirmation (it does nothing real)."
    override val risk = ToolRisk.HIGH
    override val isIdempotent = false
    override val arguments = listOf(ToolArgument("note", ArgType.STRING, required = false))
    override suspend fun execute(arguments: Map<String, Any?>): ToolResult =
        ToolResult.Success("Demo action approved and executed (it has no real effect).")
}

fun builtinTools(deviceInfo: () -> DeviceInfo, appInfo: () -> AppInfo): List<AuraTool> = listOf(
    GetCurrentTimeTool(), GetAppInfoTool(appInfo), GetDeviceInfoTool(deviceInfo),
    EchoTool(), CalculateTool(), ConfirmationDemoTool()
)
