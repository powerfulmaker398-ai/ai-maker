package com.aura.ai.agent

import com.aura.ai.data.remote.SafeLog
import com.aura.ai.domain.AIProvider
import com.aura.ai.domain.AIRequest
import com.aura.ai.domain.AIResponse
import com.aura.ai.domain.AIResult
import com.aura.ai.domain.DemoAIProvider
import com.aura.ai.domain.SystemPrompts
import com.aura.ai.intent.IntentResult
import com.aura.ai.permissions.SecurityPolicy
import com.aura.ai.planner.Plan
import com.aura.ai.planner.PlanResult
import com.aura.ai.planner.PlanValidation
import com.aura.ai.planner.PlanValidator
import com.aura.ai.planner.Planner
import com.aura.ai.task.StepRecord
import com.aura.ai.task.StepStatus
import com.aura.ai.task.Task
import com.aura.ai.task.TaskRepository
import com.aura.ai.task.TaskState
import com.aura.ai.task.TimelineEntry
import com.aura.ai.tools.RouteContext
import com.aura.ai.tools.ToolCall
import com.aura.ai.tools.ToolProtocol
import com.aura.ai.tools.ToolRegistry
import com.aura.ai.tools.ToolResult
import com.aura.ai.tools.ToolRouter
import com.aura.ai.tools.describe
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.util.UUID

data class AgentConfig(
    val maxSteps: Int = 10,
    val maxDurationMs: Long = 60_000,
    val maxRetriesPerStep: Int = 2,
    val toolTimeoutMs: Long = 15_000
)

data class AgentResult(
    val taskId: String,
    val state: TaskState,
    val finalText: String?,
    val provider: String?,
    val error: String?
)

interface AgentRunner {
    suspend fun execute(userRequest: String, intent: IntentResult, onTaskCreated: (String) -> Unit = {}): AgentResult
}

fun interface EventSink { suspend fun emit(event: AgentEvent) }

/** Timeline events. [detail] must never contain secrets or full tool arguments. */
sealed class AgentEvent(val label: String, val detail: String? = null) {
    data object TaskCreated : AgentEvent("Task created")
    data class IntentDetected(val type: String) : AgentEvent("Intent detected", type)
    data class PlanCreated(val steps: Int) : AgentEvent("Plan created", "$steps step(s)")
    data object PlanValidated : AgentEvent("Plan validated")
    data class PlanRejected(val reason: String) : AgentEvent("Plan rejected", reason)
    data class StepStarted(val index: Int, val description: String) : AgentEvent("Step $index started", description)
    data class ToolRequested(val tool: String) : AgentEvent("Tool requested", tool)
    data class PermissionRequested(val tool: String, val risk: String) : AgentEvent("Permission requested", "$tool (risk $risk)")
    data class PermissionGranted(val tool: String) : AgentEvent("Permission granted", tool)
    data class PermissionDenied(val tool: String) : AgentEvent("Permission denied", tool)
    data class ToolCompleted(val tool: String) : AgentEvent("Tool completed", tool)
    data class ToolFailed(val tool: String, val reason: String) : AgentEvent("Tool failed", "$tool: $reason")
    data class StepCompleted(val index: Int) : AgentEvent("Step $index completed")
    data class AgentRetrying(val index: Int, val attempt: Int) : AgentEvent("Retrying step $index", "retry $attempt")
    data class FinalResponse(val provider: String) : AgentEvent("Final response generated", provider)
    data object AgentCompleted : AgentEvent("Agent completed")
    data class AgentFailed(val reason: String) : AgentEvent("Agent failed", reason)
    data object AgentCancelled : AgentEvent("Agent cancelled")
    data object AgentTimedOut : AgentEvent("Agent timed out")
}

data class Observation(val tool: String, val result: ToolResult.Success)

/** Stops suspicious repetition: the same call too often, or an A,B,A,B,A,B pattern. */
class LoopGuard(private val maxIdentical: Int = 3) {
    private val counts = HashMap<String, Int>()
    private val history = ArrayList<String>()

    /** Returns false if this call looks like a loop and must not run. */
    fun record(tool: String, args: Map<String, Any?>): Boolean {
        val key = tool + "|" + args.toSortedMap().toString()
        val c = (counts[key] ?: 0) + 1
        counts[key] = c
        history += key
        if (c > maxIdentical) return false
        if (history.size >= 6) {
            val l = history.takeLast(6)
            if (l[0] == l[2] && l[2] == l[4] && l[1] == l[3] && l[3] == l[5] && l[0] != l[1]) return false
        }
        return true
    }
}

interface AgentResponder { suspend fun respond(userRequest: String, observations: List<Observation>): AIResult }

object LocalSummary {
    const val PROVIDER = "AURA Agent (local summary)"
    fun build(observations: List<Observation>): AIResult =
        AIResult.Success(
            AIResponse(observations.joinToString("\n") { "• ${it.tool}: ${it.result.summary}" }.ifBlank { "Done." }, PROVIDER)
        )
}

/**
 * Writes the final answer from REAL tool results. With the demo provider, or if the cloud call fails,
 * it returns a clearly labelled local summary instead of pretending an AI answered.
 */
class AIAgentResponder(private val providerSource: () -> AIProvider) : AgentResponder {
    override suspend fun respond(userRequest: String, observations: List<Observation>): AIResult {
        val provider = providerSource()
        if (provider is DemoAIProvider) return LocalSummary.build(observations)
        val results = observations.joinToString("\n") { ToolProtocol.resultJson(it.tool, it.result) }
        val request = AIRequest(
            SystemPrompts.AURA + "\n" + SystemPrompts.AGENT_RESPONSE, emptyList(),
            "User request: $userRequest\n\nTool results (JSON produced by AURA):\n$results"
        )
        val r = try {
            provider.generate(request)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return LocalSummary.build(observations)
        }
        return if (r is AIResult.Success) r else LocalSummary.build(observations)
    }
}

/**
 * The agent loop: understand -> plan -> validate -> (execute step -> observe -> retry/continue)* -> respond.
 * Bounded by step count, total time, per-tool timeout, retry limits and loop detection.
 * Every state change is persisted; failures become structured task failures, never crashes.
 */
class AgentEngine(
    private val planner: Planner,
    private val router: ToolRouter,
    private val registry: ToolRegistry,
    private val policy: SecurityPolicy,
    private val tasks: TaskRepository,
    private val responder: AgentResponder,
    private val config: AgentConfig = AgentConfig(),
    private val now: () -> Long = { System.currentTimeMillis() }
) : AgentRunner {

    override suspend fun execute(userRequest: String, intent: IntentResult, onTaskCreated: (String) -> Unit): AgentResult {
        val t = Tracker(
            Task(UUID.randomUUID().toString(), userRequest, intent.goal, TaskState.QUEUED, now(), now())
        )
        t.log(AgentEvent.TaskCreated)
        onTaskCreated(t.task.id)
        return try {
            withTimeout(config.maxDurationMs) { run(t, userRequest, intent) }
        } catch (e: TimeoutCancellationException) {
            withContext(NonCancellable) { t.finish(TaskState.TIMED_OUT, AgentEvent.AgentTimedOut, "Task timed out.") }
        } catch (e: CancellationException) {
            withContext(NonCancellable) { t.finish(TaskState.CANCELLED, AgentEvent.AgentCancelled, "Task cancelled.") }
            throw e
        } catch (e: Exception) {
            SafeLog.w("Agent internal error ${e.javaClass.simpleName}")
            withContext(NonCancellable) {
                t.finish(TaskState.FAILED, AgentEvent.AgentFailed("Internal error"), "Internal error (${e.javaClass.simpleName}).")
            }
        }
    }

    private suspend fun run(t: Tracker, userRequest: String, intent: IntentResult): AgentResult {
        t.transition(TaskState.UNDERSTANDING)
        t.log(AgentEvent.IntentDetected(intent.type.name))
        t.transition(TaskState.PLANNING)

        val raw: Plan = when (val p = planner.createPlan(userRequest, intent.goal)) {
            is PlanResult.Valid -> p.plan
            is PlanResult.Invalid -> return reject(t, p.reason)
        }
        t.log(AgentEvent.PlanCreated(raw.steps.size))
        val plan: Plan = when (val v = PlanValidator.validate(raw, registry, policy, config.maxSteps)) {
            is PlanValidation.Valid -> v.plan
            is PlanValidation.Invalid -> return reject(t, v.reason)
        }
        t.setPlan(plan)
        t.log(AgentEvent.PlanValidated)
        t.transition(TaskState.RUNNING)

        val observations = mutableListOf<Observation>()
        val guard = LoopGuard()
        var attemptsUsed = 0

        for ((index, step) in plan.steps.withIndex()) {
            currentCoroutineContext().ensureActive()
            val toolName = step.toolName
            if (toolName == null) { t.stepStatus(index, StepStatus.DONE, "Final answer written below"); continue }
            if (!guard.record(toolName, step.arguments)) {
                return fail(t, "Agent stopped: repeated identical tool calls were detected (possible loop).")
            }
            var retries = 0
            attempts@ while (true) {
                if (attemptsUsed >= config.maxSteps) {
                    return fail(t, "Agent stopped because the maximum number of steps was reached.")
                }
                attemptsUsed++
                t.transition(TaskState.RUNNING)
                t.setCurrent(index)
                t.stepStatus(index, StepStatus.RUNNING, null)
                t.log(AgentEvent.StepStarted(index + 1, step.description))
                t.log(AgentEvent.ToolRequested(toolName))
                t.transition(TaskState.WAITING_RESULT)

                val ctx = RouteContext(t.task.id, step.id, step.description, step.requiresConfirmation, config.toolTimeoutMs) { ev ->
                    t.log(ev)
                    if (ev is AgentEvent.PermissionRequested) t.transition(TaskState.WAITING_PERMISSION)
                    if (ev is AgentEvent.PermissionGranted) t.transition(TaskState.WAITING_RESULT)
                }
                val result = router.route(ToolCall(toolName, step.arguments), ctx)
                if (result is ToolResult.Success) {
                    t.log(AgentEvent.ToolCompleted(toolName))
                    t.stepStatus(index, StepStatus.DONE, result.summary)
                    t.log(AgentEvent.StepCompleted(index + 1))
                    observations += Observation(toolName, result)
                    break@attempts
                }
                t.log(AgentEvent.ToolFailed(toolName, result.describe()))
                val transient = (result is ToolResult.Failure && result.retryable) || result is ToolResult.Timeout
                val idempotent = registry.get(toolName)?.isIdempotent == true
                if (transient && idempotent && retries < config.maxRetriesPerStep) {
                    retries++
                    t.transition(TaskState.RETRYING)
                    t.log(AgentEvent.AgentRetrying(index + 1, retries))
                    continue@attempts
                }
                t.stepStatus(index, StepStatus.FAILED, result.describe())
                return if (result is ToolResult.Denied && result.message.contains("denied by the user")) {
                    t.finish(TaskState.CANCELLED, AgentEvent.AgentCancelled, "Action denied by the user. Nothing was executed.")
                } else {
                    fail(t, "Step ${index + 1} failed: ${result.describe()}")
                }
            }
        }

        t.transition(TaskState.WAITING_RESULT)
        val response = when (val r = responder.respond(userRequest, observations)) {
            is AIResult.Success -> r.response
            is AIResult.Failure -> (LocalSummary.build(observations) as AIResult.Success).response
        }
        t.log(AgentEvent.FinalResponse(response.provider))
        return t.complete(response.text, response.provider)
    }

    private suspend fun reject(t: Tracker, reason: String): AgentResult {
        t.log(AgentEvent.PlanRejected(reason))
        return fail(t, "Plan rejected: $reason")
    }

    private suspend fun fail(t: Tracker, message: String): AgentResult =
        t.finish(TaskState.FAILED, AgentEvent.AgentFailed(message), message)

    /** Owns the in-memory task, enforces the state machine, and persists after every change. */
    private inner class Tracker(var task: Task) {
        suspend fun mutate(block: (Task) -> Task) {
            task = block(task).copy(updatedAt = now())
            try {
                tasks.save(task)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                SafeLog.w("Task save failed")
            }
        }

        suspend fun log(e: AgentEvent) {
            SafeLog.d("Agent event: ${e.label}")
            mutate { it.copy(timeline = it.timeline + TimelineEntry(now(), e.label, e.detail)) }
        }

        suspend fun transition(to: TaskState): Boolean {
            if (task.state == to) return true
            if (!task.state.canTransitionTo(to)) {
                SafeLog.w("Rejected task transition ${task.state} -> $to")
                return false
            }
            mutate { it.copy(state = to) }
            return true
        }

        suspend fun setPlan(plan: Plan) = mutate {
            it.copy(plan = plan, steps = plan.steps.map { s -> StepRecord(s.id, s.description, s.toolName) })
        }

        suspend fun setCurrent(index: Int) = mutate { it.copy(currentStep = index) }

        suspend fun stepStatus(index: Int, status: StepStatus, summary: String?) = mutate { tk ->
            tk.copy(steps = tk.steps.mapIndexed { i, s -> if (i == index) s.copy(status = status, summary = summary ?: s.summary) else s })
        }

        suspend fun finish(state: TaskState, event: AgentEvent, error: String?): AgentResult {
            if (!task.state.terminal) {
                transition(state)
                log(event)
                mutate { it.copy(error = error) }
            }
            return AgentResult(task.id, task.state, null, null, error)
        }

        suspend fun complete(text: String, provider: String): AgentResult {
            transition(TaskState.COMPLETED)
            log(AgentEvent.AgentCompleted)
            mutate { it.copy(result = text) }
            return AgentResult(task.id, task.state, text, provider, null)
        }
    }
}
