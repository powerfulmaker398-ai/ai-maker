package com.aura.ai.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aura.ai.data.config.ConfigRepository
import com.aura.ai.data.remote.ConnectionStatus
import com.aura.ai.data.remote.ConnectionTester
import com.aura.ai.domain.ConfigSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsUiState(
    val providerName: String = "",
    val baseUrl: String = "",
    val model: String = "",
    /** Only holds what the user is currently typing. Cleared after saving; the saved key is never loaded here. */
    val apiKeyInput: String = "",
    val showApiKey: Boolean = false,
    val hasSavedKey: Boolean = false,
    val maxContext: Int = ConfigRepository.DEFAULT_MAX,
    val streaming: Boolean = true,
    val demoFallback: Boolean = false,
    val status: ConnectionStatus = ConnectionStatus.NotTested,
    val message: String? = null
)

class SettingsViewModel(
    private val config: ConfigRepository,
    private val tester: ConnectionTester,
    private val clearChat: suspend () -> Unit
) : ViewModel() {
    private val _state = MutableStateFlow(fromSnapshot(config.snapshot.value))
    val state: StateFlow<SettingsUiState> = _state.asStateFlow()

    private fun fromSnapshot(s: ConfigSnapshot) = SettingsUiState(
        providerName = s.providerName, baseUrl = s.baseUrl, model = s.model, hasSavedKey = s.hasApiKey,
        maxContext = s.maxContextMessages, streaming = s.streamingEnabled, demoFallback = s.demoFallbackEnabled
    )

    fun onProviderName(v: String) = _state.update { it.copy(providerName = v, message = null) }
    fun onBaseUrl(v: String) = _state.update { it.copy(baseUrl = v, message = null) }
    fun onModel(v: String) = _state.update { it.copy(model = v, message = null) }
    fun onApiKey(v: String) = _state.update { it.copy(apiKeyInput = v, message = null) }
    fun toggleShowKey() = _state.update { it.copy(showApiKey = !it.showApiKey) }
    fun onMaxContext(v: Int) = _state.update { it.copy(maxContext = v) }
    fun onStreaming(v: Boolean) { _state.update { it.copy(streaming = v) }; saveChatSettings() }
    fun onDemoFallback(v: Boolean) { _state.update { it.copy(demoFallback = v) }; saveChatSettings() }

    fun saveChatSettings() {
        val s = _state.value
        config.saveChatSettings(s.maxContext, s.streaming, s.demoFallback)
    }

    fun save() {
        val err = persist()
        _state.update { it.copy(message = err ?: "Saved.") }
    }

    fun removeKey() {
        config.clearApiKey()
        _state.update { it.copy(hasSavedKey = false, apiKeyInput = "", status = ConnectionStatus.NotTested, message = "API key removed.") }
    }

    fun test() {
        if (_state.value.status == ConnectionStatus.Testing) return
        val err = persist()
        if (err != null) {
            _state.update { it.copy(status = ConnectionStatus.Failed("Invalid Configuration", err)) }
            return
        }
        _state.update { it.copy(status = ConnectionStatus.Testing, message = null) }
        viewModelScope.launch {
            val result = tester.test()
            _state.update { it.copy(status = result) }
        }
    }

    fun clearConversation() {
        viewModelScope.launch {
            clearChat()
            _state.update { it.copy(message = "Conversation cleared.") }
        }
    }

    private fun persist(): String? {
        val s = _state.value
        val err = config.saveProvider(s.providerName, s.baseUrl, s.model, s.apiKeyInput)
        if (err != null) return err
        config.saveChatSettings(s.maxContext, s.streaming, s.demoFallback)
        _state.update { it.copy(apiKeyInput = "", hasSavedKey = config.snapshot.value.hasApiKey) }
        return null
    }
}
