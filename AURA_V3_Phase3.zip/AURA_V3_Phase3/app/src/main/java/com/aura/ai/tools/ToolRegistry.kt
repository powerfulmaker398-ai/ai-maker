package com.aura.ai.tools

interface ToolRegistry {
    /** Returns false (and changes nothing) for duplicate or invalid names. */
    fun register(tool: AuraTool): Boolean
    fun unregister(name: String): Boolean
    fun get(name: String): AuraTool?
    fun list(): List<AuraTool>
    fun contains(name: String): Boolean
}

class InMemoryToolRegistry : ToolRegistry {
    private val tools = LinkedHashMap<String, AuraTool>()
    private val nameRule = Regex("^[a-z][a-z0-9_]{1,40}$")

    @Synchronized override fun register(tool: AuraTool): Boolean {
        if (!nameRule.matches(tool.name) || tools.containsKey(tool.name)) return false
        tools[tool.name] = tool
        return true
    }
    @Synchronized override fun unregister(name: String): Boolean = tools.remove(name) != null
    @Synchronized override fun get(name: String): AuraTool? = tools[name]
    @Synchronized override fun list(): List<AuraTool> = tools.values.toList()
    @Synchronized override fun contains(name: String): Boolean = tools.containsKey(name)
}
