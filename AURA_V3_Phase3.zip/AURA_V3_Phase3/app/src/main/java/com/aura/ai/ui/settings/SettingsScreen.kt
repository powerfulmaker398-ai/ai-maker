package com.aura.ai.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aura.ai.data.remote.ConnectionStatus
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel, onBack: () -> Unit) {
    val s by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(
                title = { Text("AURA Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("AI Provider", style = MaterialTheme.typography.titleMedium)
            Text(
                "Works with services that offer a chat-completions style API. With no key configured, AURA uses the Local Demo.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(s.providerName, viewModel::onProviderName, label = { Text("Provider name") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.baseUrl, viewModel::onBaseUrl, label = { Text("Base URL (https://…)") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
            OutlinedTextField(s.model, viewModel::onModel, label = { Text("Model") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                value = s.apiKeyInput,
                onValueChange = viewModel::onApiKey,
                label = { Text(if (s.hasSavedKey) "API key (saved, hidden; type to replace)" else "API key") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (s.showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = { TextButton(onClick = viewModel::toggleShowKey) { Text(if (s.showApiKey) "Hide" else "Show") } }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = viewModel::save) { Text("Save") }
                if (s.hasSavedKey) OutlinedButton(onClick = viewModel::removeKey) { Text("Remove saved key") }
            }
            s.message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

            OutlinedButton(onClick = viewModel::test, modifier = Modifier.fillMaxWidth(),
                enabled = s.status != ConnectionStatus.Testing) {
                Text("Test Connection (saves first)")
            }
            ConnectionRow(s.status)

            Text("Chat", style = MaterialTheme.typography.titleMedium)
            Text("Maximum context: ${s.maxContext} messages", style = MaterialTheme.typography.bodyMedium)
            Slider(
                value = s.maxContext.toFloat(),
                onValueChange = { viewModel.onMaxContext(it.roundToInt()) },
                onValueChangeFinished = viewModel::saveChatSettings,
                valueRange = 2f..50f, steps = 47
            )
            SwitchRow("Stream responses when supported", s.streaming, viewModel::onStreaming)
            SwitchRow("Use Local Demo if the cloud is unreachable", s.demoFallback, viewModel::onDemoFallback)
            OutlinedButton(onClick = viewModel::clearConversation, modifier = Modifier.fillMaxWidth()) {
                Text("Clear conversation")
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ConnectionRow(status: ConnectionStatus) {
    when (status) {
        ConnectionStatus.NotTested -> Text("Connection: Not tested")
        ConnectionStatus.Testing -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CircularProgressIndicator(Modifier.padding(2.dp))
            Text("Testing…")
        }
        is ConnectionStatus.Connected -> Text("Connection: Connected. ${status.detail}")
        is ConnectionStatus.Failed -> Text("Connection: ${status.title}. ${status.detail}", color = MaterialTheme.colorScheme.error)
    }
}
