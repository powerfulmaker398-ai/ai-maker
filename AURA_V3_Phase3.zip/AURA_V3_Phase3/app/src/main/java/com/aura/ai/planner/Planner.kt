package com.aura.ai.planner

import com.aura.ai.domain.AIProvider
import com.aura.ai.domain.AIRequest
import com.aura.ai.domain.AIResult
import com.aura.ai.domain.DemoAIProvider
import com.aura.ai.permissions.SecurityPolicy
import com.aura.ai.tools.ArgValidation
import com.aura.ai.tools.ArgumentValidator
import com.aura.ai.tools.ToolProtocol
import com.aura.ai.tools.ToolRegistry
import com.aura.ai.tools.builtin.ToolNames
import kotlinx.coroutines.CancellationException
import java.util.UUID

data class PlanStep(
    val id: String,
    val description: String,
    /** null = "write the final answer" step; it executes nothing. */
    val toolName: String?,
    val arguments: Map<String, Any?>,
    val requiresConfirmation: Boolean
)

data class Plan(val id: String, val goal: String, val steps: List<PlanStep>)

sealed class PlanResult {
    data class Valid(val plan: Plan) : PlanResult()
    /** [unavailable] = the planner could not be reached (as opposed to deciding there is nothing to do). */
    data class Invalid(val reason: String, val unavailable: Boolean = false) : PlanResult()
}

interface Planner { suspend fun createPlan(userInput: String, goal: String): PlanResult }

object PlanParser {
    private const val HARD_LIMIT = 50

    fun parse(text: String, fallbackGoal: String): PlanResult {
        val o = ToolProtocol.extractJsonObject(text) ?: return PlanResult.Invalid("The planner did not return valid JSON.")
        if (o.optString("type") == "tool_call") {
            val c = ToolProtocol.parseToolCall(text) ?: return PlanResult.Invalid("The tool call was malformed.")
            return PlanResult.Valid(Plan(newId(), fallbackGoal, listOf(PlanStep("s1", "Run ${c.tool}", c.tool, c.arguments, false))))
        }
        val arr = o.optJSONArray("steps") ?: return PlanResult.Invalid("The plan has no 'steps' array.")
        if (arr.length() == 0) return PlanResult.Invalid("The planner returned no steps.")
        if (arr.length() > HARD_LIMIT) return PlanResult.Invalid("The plan is far too long (maximum number of steps exceeded).")
        val steps = mutableListOf<PlanStep>()
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i) ?: return PlanResult.Invalid("Step ${i + 1} is malformed.")
            val tool = if (s.isNull("tool")) null else s.optString("tool").trim().ifEmpty { null }
            val args: Map<String, Any?> =
                if (s.has("arguments") && !s.isNull("arguments")) {
                    ToolProtocol.toMap(s.optJSONObject("arguments") ?: return PlanResult.Invalid("Step ${i + 1} has malformed arguments."))
                } else emptyMap()
            val desc = s.optString("description").ifBlank { tool ?: "Step ${i + 1}" }
            steps += PlanStep("s${i + 1}", desc, tool, args, s.optBoolean("requiresConfirmation", false))
        }
        return PlanResult.Valid(Plan(newId(), o.optString("goal").ifBlank { fallbackGoal }, steps))
    }

    private fun newId() = UUID.randomUUID().toString()
}

sealed class PlanValidation {
    data class Valid(val plan: Plan) : PlanValidation()
    data class Invalid(val reason: String) : PlanValidation()
}

/** Nothing is executed until the plan passes this: shape, step count, registered tools, argument schemas, risk. */
object PlanValidator {
    fun validate(plan: Plan, registry: ToolRegistry, policy: SecurityPolicy, maxSteps: Int): PlanValidation {
        if (plan.steps.isEmpty()) return PlanValidation.Invalid("The plan has no steps.")
        if (plan.steps.size > maxSteps) {
            return PlanValidation.Invalid(
                "Agent stopped because the maximum number of steps was reached (plan has ${plan.steps.size}, limit is $maxSteps)."
            )
        }
        if (plan.steps.map { it.id }.toSet().size != plan.steps.size) return PlanValidation.Invalid("Plan step ids are not unique.")
        val out = mutableListOf<PlanStep>()
        for ((i, step) in plan.steps.withIndex()) {
            val name = step.toolName
            if (name == null) {
                if (i != plan.steps.lastIndex) return PlanValidation.Invalid("Step ${i + 1} has no tool but is not the last step.")
                out += step.copy(description = step.description.take(200))
                continue
            }
            val tool = registry.get(name) ?: return PlanValidation.Invalid("Unknown tool '$name' (not registered).")
            val args = when (val v = ArgumentValidator.validate(tool.arguments, step.arguments)) {
                is ArgValidation.Invalid -> return PlanValidation.Invalid("Step ${i + 1} ($name): ${v.errors.joinToString("; ")}")
                is ArgValidation.Valid -> v.args
            }
            out += step.copy(
                description = step.description.take(200), arguments = args,
                requiresConfirmation = step.requiresConfirmation || policy.requiresConfirmation(tool.risk)
            )
        }
        if (out.none { it.toolName != null }) return PlanValidation.Invalid("The plan contains no tool steps.")
        return PlanValidation.Valid(plan.copy(steps = out))
    }
}

/** Offline planner for the built-in tools. Produces plans only from explicit keyword matches. */
class RuleBasedPlanner : Planner {
    private val exprRegex = Regex("""[0-9(][0-9+\-*/%^().\sx×÷]*[0-9)]""")
    private val operator = Regex("""[+\-*/%^]""")

    override suspend fun createPlan(userInput: String, goal: String): PlanResult {
        val text = userInput.trim()
        val found = mutableListOf<Pair<Int, PlanStep>>()
        fun add(range: IntRange?, tool: String, desc: String, args: Map<String, Any?> = emptyMap()) {
            if (range != null) found += range.first to PlanStep("", desc, tool, args, false)
        }
        add(Regex("""android version|device info(rmation)?|my (device|phone)(.s)? (info|information|model|version|specs)|phone model|device model|sdk level|what android""", RegexOption.IGNORE_CASE).find(text)?.range,
            ToolNames.DEVICE_INFO, "Get device information")
        add(Regex("""what time|current time|time is it|today's date|current date|what('s| is) the date""", RegexOption.IGNORE_CASE).find(text)?.range,
            ToolNames.TIME, "Get the current time")
        add(Regex("""app info|app version|aura version|about (this|the) app""", RegexOption.IGNORE_CASE).find(text)?.range,
            ToolNames.APP_INFO, "Get app information")
        add(Regex("""confirmation demo""", RegexOption.IGNORE_CASE).find(text)?.range,
            ToolNames.CONFIRM_DEMO, "Run the confirmation demo action")
        Regex("""^\s*echo\s+(.+)$""", RegexOption.IGNORE_CASE).find(text)?.let {
            add(it.range, ToolNames.ECHO, "Echo text", mapOf("text" to it.groupValues[1].trim()))
        }
        exprRegex.findAll(text).firstOrNull { operator.containsMatchIn(it.value) }?.let {
            val expr = it.value.trim().replace('x', '*').replace('×', '*').replace('÷', '/')
            add(it.range, ToolNames.CALCULATE, "Calculate $expr", mapOf("expression" to expr))
        }
        if (found.isEmpty()) return PlanResult.Invalid("No available tool matches this request.")
        val steps = found.sortedBy { it.first }.mapIndexed { i, p -> p.second.copy(id = "s${i + 1}") }
        return PlanResult.Valid(Plan(UUID.randomUUID().toString(), goal, steps))
    }
}

/** Asks the AI provider for a JSON plan that may only use registered tools. The result is validated before use. */
class AIPlanner(
    private val providerSource: () -> AIProvider,
    private val registry: ToolRegistry,
    private val maxSteps: Int
) : Planner {
    override suspend fun createPlan(userInput: String, goal: String): PlanResult {
        val result = try {
            providerSource().generate(AIRequest(prompt(), emptyList(), userInput))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return PlanResult.Invalid("Planner unavailable.", unavailable = true)
        }
        return when (result) {
            is AIResult.Failure -> PlanResult.Invalid("Planner unavailable: ${result.error.userMessage}", unavailable = true)
            is AIResult.Success -> PlanParser.parse(result.response.text, goal)
        }
    }

    private fun prompt(): String {
        val catalog = registry.list().joinToString("\n") { t ->
            val args = if (t.arguments.isEmpty()) "none" else t.arguments.joinToString { a -> "${a.name}:${a.type}${if (a.required) "" else "?"}" }
            "- ${t.name} (risk ${t.risk}): ${t.description} Arguments: $args"
        }
        return """
            You are the planner of an Android assistant. Turn the user's request into a plan using ONLY these tools:
            $catalog
            Reply with ONLY JSON: {"goal":"...","steps":[{"description":"...","tool":"<tool name>","arguments":{},"requiresConfirmation":false}]}
            At most $maxSteps steps. Never invent tools. Never write code. If no tool can help, reply {"goal":"...","steps":[]}.
        """.trimIndent()
    }
}

class HybridPlanner(
    private val providerSource: () -> AIProvider,
    private val ai: Planner,
    private val rules: Planner
) : Planner {
    override suspend fun createPlan(userInput: String, goal: String): PlanResult {
        if (providerSource() is DemoAIProvider) return rules.createPlan(userInput, goal)
        val r = ai.createPlan(userInput, goal)
        return if (r is PlanResult.Invalid && r.unavailable) rules.createPlan(userInput, goal) else r
    }
}
