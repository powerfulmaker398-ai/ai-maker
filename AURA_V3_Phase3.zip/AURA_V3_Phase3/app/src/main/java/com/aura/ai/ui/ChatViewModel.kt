package com.aura.ai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aura.ai.agent.AuraOrchestrator
import com.aura.ai.data.ChatRepository
import com.aura.ai.data.config.ConfigRepository
import com.aura.ai.domain.AIError
import com.aura.ai.domain.AIResult
import com.aura.ai.domain.ChatMessage
import com.aura.ai.domain.ConfigSnapshot
import com.aura.ai.domain.Role
import com.aura.ai.permissions.ConfirmationRequest
import com.aura.ai.permissions.UiConfirmationManager
import com.aura.ai.task.Task
import com.aura.ai.task.TaskRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ChatPhase { IDLE, SENDING, STREAMING, SUCCESS, ERROR }

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val phase: ChatPhase = ChatPhase.IDLE,
    val partialText: String? = null,
    val error: AIError? = null,
    val canRetry: Boolean = false,
    val providerLabel: String = "",
    /** The agent task currently running for the latest message, if any. */
    val agentTask: Task? = null
) {
    val isBusy: Boolean get() = phase == ChatPhase.SENDING || phase == ChatPhase.STREAMING
}

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(
    private val repository: ChatRepository,
    private val orchestrator: AuraOrchestrator,
    config: ConfigRepository,
    tasks: TaskRepository,
    private val confirmations: UiConfirmationManager
) : ViewModel() {
    private val phase = MutableStateFlow(ChatPhase.IDLE)
    private val partial = MutableStateFlow<String?>(null)
    private val error = MutableStateFlow<AIError?>(null)
    private val activeTaskId = MutableStateFlow<String?>(null)
    private var job: Job? = null

    val pendingConfirmation: StateFlow<ConfirmationRequest?> = confirmations.pending

    private val base = combine(repository.messages, config.snapshot, phase, partial, error) { messages, snap, ph, part, err ->
        ChatUiState(
            messages = messages,
            phase = ph,
            partialText = part,
            error = err,
            canRetry = (ph == ChatPhase.IDLE || ph == ChatPhase.ERROR || ph == ChatPhase.SUCCESS) &&
                messages.lastOrNull()?.role == Role.USER,
            providerLabel = label(snap)
        )
    }

    private val activeTask = activeTaskId.flatMapLatest { id -> if (id == null) flowOf(null) else tasks.observe(id) }

    val state: StateFlow<ChatUiState> =
        combine(base, activeTask) { b, t -> b.copy(agentTask = t) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ChatUiState())

    private fun label(s: ConfigSnapshot) =
        if (s.cloudConfigured) {
            "Cloud AI · ${s.providerName} · ${s.model}" + if (s.demoFallbackEnabled) " (demo fallback on)" else ""
        } else "Local Demo (no cloud provider configured)"

    private fun busy() = phase.value == ChatPhase.SENDING || phase.value == ChatPhase.STREAMING

    fun send(text: String) {
        if (text.isBlank() || busy()) return
        run { orchestrator.handle(text, ::onPartial, ::onTaskCreated) }
    }

    fun retry() {
        if (busy()) return
        run { repository.retry(::onPartial) }
    }

    /** Cancels generation or the running agent task. The agent persists CANCELLED and runs no further tools. */
    fun cancel() { job?.cancel() }

    /** Only the user's tap can approve or deny an action. */
    fun resolveConfirmation(approved: Boolean) = confirmations.resolve(approved)

    fun clear() {
        if (busy()) return
        viewModelScope.launch {
            repository.clear()
            error.value = null
            phase.value = ChatPhase.IDLE
        }
    }

    fun dismissError() { error.value = null; if (phase.value == ChatPhase.ERROR) phase.value = ChatPhase.IDLE }

    private fun onTaskCreated(id: String) { activeTaskId.value = id }

    private fun onPartial(text: String) {
        if (text.isEmpty()) { partial.value = null; phase.value = ChatPhase.SENDING }
        else { partial.value = text; phase.value = ChatPhase.STREAMING }
    }

    private fun run(block: suspend () -> AIResult) {
        error.value = null
        partial.value = null
        phase.value = ChatPhase.SENDING
        job = viewModelScope.launch {
            try {
                when (val r = block()) {
                    is AIResult.Success -> phase.value = ChatPhase.SUCCESS
                    is AIResult.Failure -> { error.value = r.error; phase.value = ChatPhase.ERROR }
                }
            } catch (e: CancellationException) {
                phase.value = ChatPhase.IDLE
                throw e
            } finally {
                partial.value = null
                activeTaskId.value = null
            }
        }
    }
}
