package com.aura.ai

import android.app.Application
import com.aura.ai.di.AppContainer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AuraApp : Application() {
    val container: AppContainer by lazy { AppContainer(this) }

    override fun onCreate() {
        super.onCreate()
        // Tasks that were mid-run when the app was closed cannot resume: mark them FAILED.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try { container.taskRepository.failInterrupted() } catch (e: Exception) { /* non-fatal */ }
        }
    }
}
