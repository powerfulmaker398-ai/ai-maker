package com.aura.ai.tools

import com.aura.ai.agent.AgentEvent
import com.aura.ai.agent.EventSink
import com.aura.ai.permissions.ConfirmationManager
import com.aura.ai.permissions.ConfirmationRequest
import com.aura.ai.permissions.PermissionManager
import com.aura.ai.permissions.PolicyDecision
import com.aura.ai.permissions.SecurityPolicy
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withTimeoutOrNull

data class RouteContext(
    val taskId: String,
    val stepId: String,
    val description: String,
    val stepRequiresConfirmation: Boolean,
    val toolTimeoutMs: Long,
    val sink: EventSink
)

/**
 * The single gate to tool execution: exists? -> arguments valid? -> policy -> permission -> confirmation -> execute.
 * Neither the UI nor an AI provider can call a tool any other way.
 */
class ToolRouter(
    private val registry: ToolRegistry,
    private val policy: SecurityPolicy,
    private val permissions: PermissionManager,
    private val confirmations: ConfirmationManager
) {
    suspend fun route(call: ToolCall, ctx: RouteContext): ToolResult {
        val tool = registry.get(call.tool) ?: return ToolResult.NotAvailable("Tool '${call.tool}' is not registered.")
        val args = when (val v = ArgumentValidator.validate(tool.arguments, call.arguments)) {
            is ArgValidation.Invalid -> return ToolResult.InvalidArguments(v.errors.joinToString("; "))
            is ArgValidation.Valid -> v.args
        }
        val decision = policy.evaluate(tool)
        if (decision == PolicyDecision.DENY) return ToolResult.Denied("Blocked by AURA's security policy.")
        if (!permissions.isGranted(tool)) return ToolResult.PermissionRequired("Permission required for '${tool.name}'.")

        // The plan/AI may ADD a confirmation requirement but can never remove one required by policy.
        if (decision == PolicyDecision.REQUIRE_CONFIRMATION || ctx.stepRequiresConfirmation) {
            ctx.sink.emit(AgentEvent.PermissionRequested(tool.name, tool.risk.name))
            val approved = confirmations.confirm(
                ConfirmationRequest(ctx.taskId, ctx.stepId, tool.name, ctx.description, tool.risk)
            )
            if (!approved) {
                ctx.sink.emit(AgentEvent.PermissionDenied(tool.name))
                return ToolResult.Denied("The action was denied by the user.")
            }
            ctx.sink.emit(AgentEvent.PermissionGranted(tool.name))
        }
        currentCoroutineContext().ensureActive()
        return try {
            withTimeoutOrNull(ctx.toolTimeoutMs) { tool.execute(args) } ?: ToolResult.Timeout
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ToolResult.Failure("Tool '${tool.name}' failed (${e.javaClass.simpleName}).")
        }
    }
}
