package com.aura.ai.domain

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Tries [primary]; on availability failures (offline, timeout, server error, rate limit) uses [fallback].
 * Auth/config errors are NOT masked: they need the user's attention.
 * The fallback response is labelled "<name> (fallback)" so the UI never implies the primary answered.
 */
class FallbackAIProvider(
    private val primary: AIProvider,
    private val fallback: AIProvider
) : AIStreamingProvider {
    override val name: String get() = primary.name
    override val supportsStreaming: Boolean get() = primary is AIStreamingProvider && primary.supportsStreaming

    override suspend fun generate(request: AIRequest): AIResult {
        val first = primary.generate(request)
        return if (first is AIResult.Failure && first.error.type in FALLBACK_ON) {
            markFallback(fallback.generate(request))
        } else first
    }

    override fun stream(request: AIRequest): Flow<StreamEvent> = flow {
        val p = primary as? AIStreamingProvider
        if (p == null || !p.supportsStreaming) {
            emit(toEvent(generate(request)))
            return@flow
        }
        var sawDelta = false
        var failure: AIError? = null
        p.stream(request).collect { ev ->
            when (ev) {
                is StreamEvent.Delta -> { sawDelta = true; emit(ev) }
                is StreamEvent.Complete -> emit(ev)
                is StreamEvent.Failed -> failure = ev.error
            }
        }
        val f = failure
        if (f != null) {
            if (!sawDelta && f.type in FALLBACK_ON) emit(toEvent(markFallback(fallback.generate(request))))
            else emit(StreamEvent.Failed(f))
        }
    }

    private fun markFallback(r: AIResult): AIResult =
        if (r is AIResult.Success) AIResult.Success(r.response.copy(provider = "${r.response.provider} (fallback)")) else r

    private fun toEvent(r: AIResult): StreamEvent = when (r) {
        is AIResult.Success -> StreamEvent.Complete(r.response)
        is AIResult.Failure -> StreamEvent.Failed(r.error)
    }

    companion object {
        val FALLBACK_ON = setOf(
            AIErrorType.NETWORK_UNAVAILABLE, AIErrorType.TIMEOUT,
            AIErrorType.SERVER_ERROR, AIErrorType.RATE_LIMITED
        )
    }
}
