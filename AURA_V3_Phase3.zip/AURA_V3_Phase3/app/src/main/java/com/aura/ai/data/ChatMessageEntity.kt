package com.aura.ai.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.aura.ai.domain.ChatMessage
import com.aura.ai.domain.Role

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val content: String,
    val createdAt: Long,
    val provider: String? = null,
    val model: String? = null
)

fun ChatMessageEntity.toDomain() = ChatMessage(
    id = id,
    role = runCatching { Role.valueOf(role) }.getOrDefault(Role.ASSISTANT),
    content = content,
    createdAt = createdAt,
    provider = provider,
    model = model
)

fun ChatMessage.toEntity() = ChatMessageEntity(
    id = id, role = role.name, content = content, createdAt = createdAt, provider = provider, model = model
)
