package com.aura.ai.data.remote

import com.aura.ai.data.config.ConfigRepository
import com.aura.ai.domain.AIProvider
import com.aura.ai.domain.AIProviderConfig
import com.aura.ai.domain.FallbackAIProvider
import okhttp3.OkHttpClient

/** Chooses the provider for the NEXT request from current settings. */
class AIProviderFactory(
    private val config: ConfigRepository,
    private val client: OkHttpClient,
    private val network: NetworkMonitor,
    private val demo: AIProvider
) {
    fun cloud(cfg: AIProviderConfig, streaming: Boolean = config.snapshot.value.streamingEnabled): AIProvider =
        CloudAIProvider(cfg, client, network, streamingEnabled = streaming)

    fun current(): AIProvider {
        val snap = config.snapshot.value
        if (!snap.cloudConfigured) return demo
        val cloud = cloud(config.loadProviderConfig(), snap.streamingEnabled)
        return if (snap.demoFallbackEnabled) FallbackAIProvider(cloud, demo) else cloud
    }
}
