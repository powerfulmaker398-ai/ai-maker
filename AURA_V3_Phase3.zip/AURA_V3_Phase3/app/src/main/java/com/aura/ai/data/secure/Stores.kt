package com.aura.ai.data.secure

import android.content.Context

interface KeyValueStore {
    fun getString(key: String): String?
    fun putString(key: String, value: String?)
}

interface SecretStore {
    fun get(): String?
    /** null or blank removes the secret. */
    fun set(secret: String?)
}

class SharedPrefsStore(context: Context, name: String) : KeyValueStore {
    private val prefs = context.applicationContext.getSharedPreferences(name, Context.MODE_PRIVATE)
    override fun getString(key: String): String? = prefs.getString(key, null)
    override fun putString(key: String, value: String?) {
        val editor = prefs.edit()
        if (value == null) editor.remove(key) else editor.putString(key, value)
        editor.apply()
    }
}
