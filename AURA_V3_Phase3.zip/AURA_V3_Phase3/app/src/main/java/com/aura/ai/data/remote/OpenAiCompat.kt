package com.aura.ai.data.remote

import com.aura.ai.domain.AIErrorType
import com.aura.ai.domain.AIError
import com.aura.ai.domain.AIRequest
import com.aura.ai.domain.AIResponse
import com.aura.ai.domain.AIResult
import com.aura.ai.domain.Role
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** Request building and response parsing for the "chat completions" wire format. Pure functions, unit-testable. */
object OpenAiCompat {
    fun chatUrl(baseUrl: String): String = baseUrl.trim().trimEnd('/') + "/chat/completions"

    fun buildBody(model: String, request: AIRequest, stream: Boolean): String {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", request.systemPrompt))
        request.conversation.forEach {
            messages.put(
                JSONObject().put("role", if (it.role == Role.USER) "user" else "assistant").put("content", it.content)
            )
        }
        messages.put(JSONObject().put("role", "user").put("content", request.userInput))
        val body = JSONObject().put("model", model).put("messages", messages).put("stream", stream)
        request.temperature?.let { body.put("temperature", it) }
        request.maxOutputTokens?.let { body.put("max_tokens", it) }
        return body.toString()
    }

    fun parseCompletion(body: String, provider: String, model: String): AIResult {
        fun fail(t: AIErrorType) = AIResult.Failure(AIError(t, provider = provider))
        return try {
            val choices = JSONObject(body).optJSONArray("choices")
            val message = choices?.optJSONObject(0)?.optJSONObject("message")
            when {
                message == null -> fail(AIErrorType.INVALID_RESPONSE)
                message.isNull("content") -> fail(AIErrorType.EMPTY_RESPONSE)
                else -> {
                    val text = message.getString("content")
                    if (text.isBlank()) fail(AIErrorType.EMPTY_RESPONSE)
                    else AIResult.Success(AIResponse(text, provider, model))
                }
            }
        } catch (e: JSONException) {
            fail(AIErrorType.INVALID_RESPONSE)
        }
    }

    /** Returns the text delta of one SSE data payload ("" if none). Throws JSONException on malformed JSON. */
    fun parseStreamDelta(data: String): String {
        val choices = JSONObject(data).optJSONArray("choices") ?: return ""
        val delta = choices.optJSONObject(0)?.optJSONObject("delta") ?: return ""
        return if (delta.isNull("content")) "" else delta.getString("content")
    }
}
