package com.aura.ai.intent

import com.aura.ai.domain.AIProvider
import com.aura.ai.domain.AIRequest
import com.aura.ai.domain.AIResult
import com.aura.ai.domain.DemoAIProvider
import com.aura.ai.tools.ToolProtocol
import kotlinx.coroutines.CancellationException

enum class IntentType(val usesAgent: Boolean) {
    CHAT(false), QUESTION(false), TASK(true), MULTI_STEP_TASK(true),
    TOOL_REQUEST(true), SYSTEM_COMMAND(true), UNKNOWN(false)
}

/** [confidence] is model metadata only. It is never treated as a probability and never gates a decision. */
data class IntentResult(
    val type: IntentType,
    val goal: String,
    val confidence: Double? = null,
    val source: String = "heuristic"
)

interface IntentClassifier { suspend fun classify(userInput: String): IntentResult }

/** Local, deterministic classifier. Only recognises requests the built-in tools can serve. */
class HeuristicIntentClassifier : IntentClassifier {
    private val calcWord = Regex("""\b(calculate|compute|evaluate)\b""", RegexOption.IGNORE_CASE)
    private val calcExpr = Regex("""\d\s*[+\-*/%^x×÷]\s*[\d(]""", RegexOption.IGNORE_CASE)
    private val mathLead = Regex("""^\s*(what is|what's|how much is)\b""", RegexOption.IGNORE_CASE)
    private val device = Regex("""\b(android version|device info(rmation)?|my (device|phone)(.s)? (info|information|model|version|specs)|phone model|device model|sdk level|what android)\b""", RegexOption.IGNORE_CASE)
    private val time = Regex("""\b(what time|current time|time is it|today's date|current date|what('s| is) the date)\b""", RegexOption.IGNORE_CASE)
    private val appInfo = Regex("""\b(app info|app version|aura version|about (this|the) app)\b""", RegexOption.IGNORE_CASE)
    private val echo = Regex("""^\s*echo\b""", RegexOption.IGNORE_CASE)
    private val confirmDemo = Regex("""confirmation demo""", RegexOption.IGNORE_CASE)
    private val followUp = Regex("""\b(and|then)\b.*\b(summari[sz]e|explain|tell me|report)\b""", RegexOption.IGNORE_CASE)
    private val questionLead = Regex("""^\s*(what|how|why|who|when|where|explain|define|describe|can you|could you)\b""", RegexOption.IGNORE_CASE)

    override suspend fun classify(userInput: String): IntentResult {
        val text = userInput.trim()
        val goal = text.take(200)
        if (text.isEmpty()) return IntentResult(IntentType.UNKNOWN, goal)
        val hits = listOf(
            (calcExpr.containsMatchIn(text) && (calcWord.containsMatchIn(text) || mathLead.containsMatchIn(text))),
            device.containsMatchIn(text), time.containsMatchIn(text), appInfo.containsMatchIn(text),
            echo.containsMatchIn(text), confirmDemo.containsMatchIn(text)
        ).count { it }
        val type = when {
            hits >= 2 || (hits == 1 && followUp.containsMatchIn(text)) -> IntentType.MULTI_STEP_TASK
            hits == 1 -> IntentType.TASK
            text.endsWith("?") || questionLead.containsMatchIn(text) -> IntentType.QUESTION
            else -> IntentType.CHAT
        }
        return IntentResult(type, goal)
    }
}

/** Asks the AI provider for structured JSON. Anything unparseable or invalid becomes UNKNOWN. */
class AIIntentClassifier(private val providerSource: () -> AIProvider) : IntentClassifier {
    override suspend fun classify(userInput: String): IntentResult {
        val unknown = IntentResult(IntentType.UNKNOWN, userInput.trim().take(200), source = "ai")
        val result = try {
            providerSource().generate(AIRequest(PROMPT, emptyList(), userInput))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return unknown
        }
        if (result !is AIResult.Success) return unknown
        return parse(result.response.text, userInput) ?: unknown
    }

    companion object {
        val PROMPT = """
            Classify the user's message. Reply with ONLY a JSON object:
            {"intent":"<CHAT|QUESTION|TASK|MULTI_STEP_TASK|TOOL_REQUEST|SYSTEM_COMMAND>","confidence":<0..1>,"goal":"<short goal>"}
            CHAT and QUESTION are ordinary conversation. TASK needs one action on the device. MULTI_STEP_TASK needs several.
        """.trimIndent()

        fun parse(text: String, userInput: String): IntentResult? {
            val o = ToolProtocol.extractJsonObject(text) ?: return null
            val type = runCatching { IntentType.valueOf(o.optString("intent").trim().uppercase()) }.getOrNull() ?: return null
            if (type == IntentType.UNKNOWN) return null
            val conf = if (o.has("confidence") && !o.isNull("confidence")) o.optDouble("confidence", Double.NaN) else Double.NaN
            val goal = o.optString("goal").trim().ifEmpty { userInput.trim() }.take(200)
            return IntentResult(type, goal, conf.takeIf { !it.isNaN() }?.coerceIn(0.0, 1.0), "ai")
        }
    }
}

/**
 * Heuristic first. The AI is consulted only when the heuristic already saw a task, and only with a real
 * (non-demo) provider. The AI can therefore turn a task back into chat, but can never invent a task.
 */
class HybridIntentClassifier(
    private val heuristic: IntentClassifier,
    private val ai: IntentClassifier,
    private val providerSource: () -> AIProvider
) : IntentClassifier {
    override suspend fun classify(userInput: String): IntentResult {
        val h = heuristic.classify(userInput)
        if (!h.type.usesAgent || providerSource() is DemoAIProvider) return h
        val a = ai.classify(userInput)
        return when {
            a.type == IntentType.UNKNOWN -> h
            a.type.usesAgent -> h.copy(type = a.type, goal = a.goal, confidence = a.confidence, source = "ai")
            else -> a
        }
    }
}
