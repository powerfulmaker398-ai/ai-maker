package com.aura.ai.task

import com.aura.ai.planner.Plan

enum class TaskState(val terminal: Boolean = false) {
    QUEUED, UNDERSTANDING, PLANNING, WAITING_PERMISSION, RUNNING, WAITING_RESULT, RETRYING,
    COMPLETED(true), FAILED(true), CANCELLED(true), TIMED_OUT(true);

    fun canTransitionTo(next: TaskState): Boolean {
        if (terminal || next == this) return false
        val abort = setOf(FAILED, CANCELLED, TIMED_OUT)
        val forward: Set<TaskState> = when (this) {
            QUEUED -> setOf(UNDERSTANDING)
            UNDERSTANDING -> setOf(PLANNING)
            PLANNING -> setOf(RUNNING)
            RUNNING -> setOf(WAITING_PERMISSION, WAITING_RESULT, RETRYING, COMPLETED)
            WAITING_PERMISSION -> setOf(RUNNING, WAITING_RESULT)
            WAITING_RESULT -> setOf(RUNNING, WAITING_PERMISSION, RETRYING, COMPLETED)
            RETRYING -> setOf(RUNNING, WAITING_RESULT, WAITING_PERMISSION)
            else -> emptySet()
        }
        return next in forward || next in abort
    }
}

enum class StepStatus { PENDING, RUNNING, DONE, FAILED, SKIPPED }

data class StepRecord(
    val id: String,
    val description: String,
    val tool: String?,
    val status: StepStatus = StepStatus.PENDING,
    val summary: String? = null
)

data class TimelineEntry(val time: Long, val label: String, val detail: String? = null)

data class Task(
    val id: String,
    val userRequest: String,
    val goal: String,
    val state: TaskState,
    val createdAt: Long,
    val updatedAt: Long,
    val plan: Plan? = null,
    val steps: List<StepRecord> = emptyList(),
    val currentStep: Int = 0,
    val timeline: List<TimelineEntry> = emptyList(),
    val error: String? = null,
    val result: String? = null
)
