package com.aura.ai.agent

import com.aura.ai.data.ChatRepository
import com.aura.ai.domain.AIError
import com.aura.ai.domain.AIErrorType
import com.aura.ai.domain.AIResponse
import com.aura.ai.domain.AIResult
import com.aura.ai.intent.IntentClassifier
import com.aura.ai.intent.IntentResult
import com.aura.ai.intent.IntentType
import com.aura.ai.task.TaskState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext

/**
 * Routes each user message: ordinary conversation goes to the Phase 2 chat path (no task, no tools);
 * recognised tasks go to the agent. AI-provider code lives only in ChatRepository / the planner / responder.
 */
class AuraOrchestrator(
    private val classifier: IntentClassifier,
    private val agent: AgentRunner,
    private val chat: ChatRepository
) {
    suspend fun handle(text: String, onPartial: (String) -> Unit, onTaskCreated: (String) -> Unit): AIResult {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return chat.send(text, onPartial)
        val intent = try {
            classifier.classify(trimmed)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            IntentResult(IntentType.UNKNOWN, trimmed.take(200))
        }
        if (!intent.type.usesAgent) return chat.send(trimmed, onPartial)

        chat.saveUserMessage(trimmed)
        val result = try {
            agent.execute(trimmed, intent, onTaskCreated)
        } catch (e: CancellationException) {
            withContext(NonCancellable) { chat.saveAssistantMessage("Task cancelled. Nothing further was executed.", AGENT) }
            throw e
        }
        if (result.state == TaskState.COMPLETED && result.finalText != null) {
            val provider = result.provider ?: AGENT
            chat.saveAssistantMessage(result.finalText, provider)
            return AIResult.Success(AIResponse(result.finalText, provider))
        }
        val reason = result.error ?: "The task did not complete."
        chat.saveAssistantMessage("Task ${result.state.name.lowercase().replace('_', ' ')}: $reason (details are in Tasks).", AGENT)
        return AIResult.Failure(AIError(AIErrorType.UNKNOWN, userMessage = reason, retryable = false, provider = AGENT))
    }

    private companion object { const val AGENT = "AURA Agent" }
}
