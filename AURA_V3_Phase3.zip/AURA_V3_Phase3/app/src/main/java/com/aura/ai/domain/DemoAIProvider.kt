package com.aura.ai.domain

/**
 * LOCAL DEMO / MOCK provider. No AI model, no network.
 * Every reply states that it is a demo.
 */
class DemoAIProvider : AIProvider {
    override val name: String = "Local Demo"

    private val greeting = Regex("\\b(hello|hi|hey)\\b", RegexOption.IGNORE_CASE)

    override suspend fun generate(request: AIRequest): AIResult {
        val last = request.userInput.trim()
        val body = when {
            last.isEmpty() -> "I received an empty message."
            greeting.containsMatchIn(last) -> "Hello. I am AURA, answering from the local demo provider."
            last.contains("help", ignoreCase = true) ->
                "The demo provider only echoes simple replies. Configure a cloud provider in Settings for real AI."
            else -> "I stored your message (${last.length} characters). The demo provider cannot understand it."
        }
        return AIResult.Success(
            AIResponse("$body\n\n[Local demo: no real AI model generated this reply.]", name)
        )
    }
}
