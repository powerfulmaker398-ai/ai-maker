package com.aura.ai.data.config

import com.aura.ai.data.secure.KeyValueStore
import com.aura.ai.data.secure.SecretStore
import com.aura.ai.domain.AIProviderConfig
import com.aura.ai.domain.ConfigSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ConfigRepository(
    private val store: KeyValueStore,
    private val secrets: SecretStore
) {
    private val _snapshot = MutableStateFlow(readSnapshot())
    val snapshot: StateFlow<ConfigSnapshot> = _snapshot.asStateFlow()

    private fun readSnapshot() = ConfigSnapshot(
        providerName = store.getString(K_NAME) ?: DEFAULT_NAME,
        baseUrl = store.getString(K_URL).orEmpty(),
        model = store.getString(K_MODEL).orEmpty(),
        hasApiKey = !secrets.get().isNullOrBlank(),
        maxContextMessages = (store.getString(K_MAX)?.toIntOrNull() ?: DEFAULT_MAX).coerceIn(MIN_MAX, MAX_MAX),
        streamingEnabled = store.getString(K_STREAM)?.toBooleanStrictOrNull() ?: true,
        demoFallbackEnabled = store.getString(K_FALLBACK)?.toBooleanStrictOrNull() ?: false
    )

    /** Includes the secret: only use to build a provider, never to display or log. */
    fun loadProviderConfig() = AIProviderConfig(
        providerName = store.getString(K_NAME) ?: DEFAULT_NAME,
        baseUrl = store.getString(K_URL).orEmpty(),
        model = store.getString(K_MODEL).orEmpty(),
        apiKey = secrets.get()
    )

    /** Returns an error message, or null on success. A blank [newApiKey] keeps the existing key. */
    fun saveProvider(providerName: String, baseUrl: String, model: String, newApiKey: String?): String? {
        val url = baseUrl.trim()
        if (providerName.isBlank()) return "Provider name is required."
        if (url.isNotEmpty()) AIProviderConfig.baseUrlError(url)?.let { return it }
        try {
            if (!newApiKey.isNullOrBlank()) secrets.set(newApiKey.trim())
        } catch (e: Exception) {
            return "Could not store the API key securely on this device."
        }
        store.putString(K_NAME, providerName.trim())
        store.putString(K_URL, url)
        store.putString(K_MODEL, model.trim())
        _snapshot.value = readSnapshot()
        return null
    }

    fun clearApiKey() {
        secrets.set(null)
        _snapshot.value = readSnapshot()
    }

    fun saveChatSettings(maxContext: Int, streaming: Boolean, demoFallback: Boolean) {
        store.putString(K_MAX, maxContext.coerceIn(MIN_MAX, MAX_MAX).toString())
        store.putString(K_STREAM, streaming.toString())
        store.putString(K_FALLBACK, demoFallback.toString())
        _snapshot.value = readSnapshot()
    }

    companion object {
        const val DEFAULT_NAME = "OpenAI-compatible"
        const val DEFAULT_MAX = 20
        const val MIN_MAX = 2
        const val MAX_MAX = 50
        private const val K_NAME = "provider_name"
        private const val K_URL = "base_url"
        private const val K_MODEL = "model"
        private const val K_MAX = "max_context"
        private const val K_STREAM = "streaming"
        private const val K_FALLBACK = "demo_fallback"
    }
}
