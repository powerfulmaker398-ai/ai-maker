package com.aura.ai.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.aura.ai.task.TaskDao
import com.aura.ai.task.TaskEntity

@Database(entities = [ChatMessageEntity::class, TaskEntity::class], version = 3, exportSchema = false)
abstract class AuraDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun taskDao(): TaskDao

    companion object {
        /** Phase 2: record which provider/model produced each assistant message. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN provider TEXT")
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN model TEXT")
            }
        }

        /** Phase 3: adds the tasks table. chat_messages is not touched, so all chat history is kept. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS tasks (" +
                        "id TEXT NOT NULL, userRequest TEXT NOT NULL, goal TEXT NOT NULL, state TEXT NOT NULL, " +
                        "createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, planJson TEXT, " +
                        "stepsJson TEXT NOT NULL, timelineJson TEXT NOT NULL, currentStep INTEGER NOT NULL, " +
                        "error TEXT, result TEXT, PRIMARY KEY(id))"
                )
            }
        }

        fun create(context: Context): AuraDatabase =
            Room.databaseBuilder(context.applicationContext, AuraDatabase::class.java, "aura.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                .build()
    }
}
